// FLOW AUTOMI V3.2 - Advanced Automation Engine
(function() {
    let isRunning = false;
    let isPaused = false;
    let currentPromptIndex = 0;

    const i18nData = {
        ko: {
            "tab-lbl-prompt": "자동화 설정",
            "tab-lbl-settings": "설정",
            "tab-lbl-logs": "로그 보고",
            "tab-lbl-info": "정보",
            "i18n-model-title": "이미지 모델 선택",
            "i18n-ratio-title": "이미지 비율",
            "i18n-count-title": "프롬프트당 생성 수량",
            "i18n-prompt-title": "프롬프트",
            "i18n-advanced-title": "고급 설정",
            "lbl-language": "언어 설정 (Language)",
            "lbl-autodl": "자동 다운로드 (점검 중)",
            "lbl-waittime": "생성 후 대기 시간 (초)",
            "lbl-retrycount": "실패 시 재시도 횟수",
            "lbl-delaytime": "동작 간 지연 시간 (초)",
            "saveSettingsBtn": "설정 저장",
            "startBtn": "자동화 시작",
            "pauseBtn": "일시정지",
            "stopBtn": "중지",
            "importBtn": "txt 파일",
            "clearBtn": "전체 삭제",
            "promptInputPlaceholder": "프롬프트를 입력하세요 (프롬프트 사이를 한 칸 띄워서 구분)",
            "statusMsgReady": "준비됨",
            "lbl-connection": "🔗 연결: ",
            "lbl-gotoflow": "FLOW로 이동",
            "info-title": "준비 중인 페이지입니다",
            "info-desc": "사이트 소개 및 안내 정보가<br>이곳에 표시될 예정입니다.",
            "wrong-title": "FLOW 페이지가 아닙니다",
            "wrong-desc": "FLOW AUTOMI 도구는 Google FLOW<br>작업 공간 페이지에서만 작동합니다.",
            "promptCountSuffix": "개 프롬프트",
            "logSystemReady": "시스템 준비 완료. 구글 FLOW 탭을 열어주세요.",
            "logSettingsSaved": "💾 설정이 로컬 저장소에 저장되었습니다.",
            "alertSettingsSaved": "설정이 저장되었습니다.",
            "logWaitGen": "⏳ 생성 대기 중 ({time}초)...",
            "logDone": "✅ 작업 완료 ({current}/{total})",
            "logStopped": "🛑 자동화가 중지되었습니다.",
            "logPaused": "⏸ 작업이 일시 정지되었습니다. 다시 시작을 누르면 이어서 진행합니다.",
            "resumeBtn": "자동화 재개",
            "logAllDone": "🎉 모든 자동화 작업이 완료되었습니다!",
            "logGenStartFail": "⚠️ 생성 시작 감지 실패. ({error})",
            "logRetryFailed": "❌ [실패] {count}회 재시도 후에도 생성을 시작하지 못했습니다. 다음 프롬프트로 넘어갑니다.",
            "errEditorBusy": "에디터에 텍스트가 남아있음",
            "logFatalError": "❌ 치명적 오류: {error}"
        },
        en: {
            "tab-lbl-prompt": "Automation",
            "tab-lbl-settings": "Settings",
            "tab-lbl-logs": "Logs",
            "tab-lbl-info": "Info",
            "i18n-model-title": "Model Selection",
            "i18n-ratio-title": "Image Ratio",
            "i18n-count-title": "Quantity per Prompt",
            "i18n-prompt-title": "Prompts",
            "i18n-advanced-title": "Advanced Settings",
            "lbl-language": "Language Settings",
            "lbl-autodl": "Auto Download (Mainte.)",
            "lbl-waittime": "Wait time after gen (s)",
            "lbl-retrycount": "Retry count on failure",
            "lbl-delaytime": "Delay between actions (s)",
            "saveSettingsBtn": "Save Settings",
            "startBtn": "Start Automation",
            "pauseBtn": "Pause",
            "stopBtn": "Stop",
            "importBtn": "Import txt",
            "clearBtn": "Clear All",
            "promptInputPlaceholder": "Enter prompts (Separate prompts with a blank line)",
            "statusMsgReady": "Ready",
            "lbl-connection": "🔗 Connection: ",
            "lbl-gotoflow": "Go to FLOW",
            "info-title": "Under Construction",
            "info-desc": "Information about the tool<br>will be displayed here.",
            "wrong-title": "Not a FLOW Page",
            "wrong-desc": "FLOW AUTOMI only works on<br>Google FLOW workspace pages.",
            "promptCountSuffix": " prompts",
            "logSystemReady": "System ready. Please open Google FLOW tab.",
            "logSettingsSaved": "💾 Settings saved to local storage.",
            "alertSettingsSaved": "Settings have been saved.",
            "logWaitGen": "⏳ Waiting for generation ({time}s)...",
            "logDone": "✅ Task completed ({current}/{total})",
            "logStopped": "🛑 Automation stopped.",
            "logPaused": "⏸ Task paused. Click resume to continue.",
            "resumeBtn": "Resume Automation",
            "logAllDone": "🎉 All automation tasks completed!",
            "logGenStartFail": "⚠️ Failed to detect generation start. ({error})",
            "logRetryFailed": "❌ [Failed] Failed to start generation after {count} attempts. Moving to next prompt.",
            "errEditorBusy": "Text remains in editor",
            "logFatalError": "❌ Fatal Error: {error}"
        }
    };

    let currentLang = 'ko';

    const t = (key, params = {}) => {
        let text = i18nData[currentLang][key] || key;
        for (const p in params) {
            text = text.replace(`{${p}}`, params[p]);
        }
        return text;
    };

    const applyLanguage = (lang) => {
        currentLang = lang || 'ko';
        const data = i18nData[currentLang];
        
        // Update elements with IDs or specific classes
        for (const key in data) {
            const el = document.getElementById(key);
            if (el) {
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    if (key === 'promptInputPlaceholder') el.placeholder = data[key];
                } else {
                    el.innerHTML = data[key];
                }
            }
        }

        // Section titles (using class)
        document.querySelectorAll('.i18n-model-title').forEach(el => el.innerText = data['i18n-model-title']);
        document.querySelectorAll('.i18n-ratio-title').forEach(el => el.innerText = data['i18n-ratio-title']);
        document.querySelectorAll('.i18n-count-title').forEach(el => el.innerText = data['i18n-count-title']);
        document.querySelectorAll('.i18n-prompt-title').forEach(el => el.innerText = data['i18n-prompt-title']);
        document.querySelectorAll('.i18n-advanced-title').forEach(el => el.innerText = data['i18n-advanced-title']);

        // Update prompt count
        const input = document.getElementById('promptInput');
        if (input) {
            const prompts = input.value.split(/\n\s*\n/).filter(l => l.trim() !== '');
            document.getElementById('promptCount').innerText = `${prompts.length}${t('promptCountSuffix')}`;
            input.placeholder = t('promptInputPlaceholder');
        }

        // Update status if present
        const statusMsg = document.getElementById('statusMsg');
        if (statusMsg && statusMsg.innerText === i18nData['ko']['statusMsgReady'] || statusMsg.innerText === i18nData['en']['statusMsgReady']) {
            statusMsg.innerText = t('statusMsgReady');
        }
    };

    const init = () => {
        setupUI();
        initAutomation();
        loadSettings();
    };

    const setupUI = () => {
        const isFlowUrl = (url) => {
            if (!url) return false;
            try {
                const parsed = new URL(url);
                return parsed.hostname === 'labs.google' &&
                    parsed.pathname.includes('/fx/') &&
                    parsed.pathname.includes('/tools/flow');
            } catch (e) {
                return url.includes('labs.google') && url.includes('/tools/flow');
            }
        };

        // Tab Switching
        document.querySelectorAll('.tab').forEach(tab => {
            tab.onclick = () => {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
            };
        });

        const profileLoginBtn = document.getElementById('profileLoginBtn');
        const profileMenu = document.getElementById('profileMenu');
        const myPageBtn = document.getElementById('myPageBtn');
        const myPagePanel = document.getElementById('myPagePanel');
        const noticeAdminBtn = document.getElementById('noticeAdminBtn');
        const noticeAdminPanel = document.getElementById('noticeAdminPanel');
        const noticeAdminTitle = document.getElementById('noticeAdminTitle');
        const noticeAdminMessage = document.getElementById('noticeAdminMessage');
        const noticeAdminSaveBtn = document.getElementById('noticeAdminSaveBtn');
        const noticeAdminClearBtn = document.getElementById('noticeAdminClearBtn');
        const noticeAdminList = document.getElementById('noticeAdminList');
        const logoutBtn = document.getElementById('logoutBtn');
        let editingAnnouncementId = null;

        const closeProfileMenu = () => {
            if (!profileMenu) return;
            profileMenu.classList.remove('open');
            profileMenu.setAttribute('aria-hidden', 'true');
        };

        const setMyPageOpen = (isOpen) => {
            if (!myPagePanel) return;
            myPagePanel.classList.toggle('open', Boolean(isOpen));
            myPagePanel.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
            if (!isOpen) setNoticeAdminOpen(false);
        };

        const setNoticeAdminOpen = (isOpen) => {
            if (!noticeAdminPanel) return;
            noticeAdminPanel.classList.toggle('open', Boolean(isOpen));
            noticeAdminPanel.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
        };

        const resetNoticeAdminForm = () => {
            editingAnnouncementId = null;
            if (noticeAdminTitle) noticeAdminTitle.value = '';
            if (noticeAdminMessage) noticeAdminMessage.value = '';
            if (noticeAdminSaveBtn) noticeAdminSaveBtn.innerText = '게시';
        };

        const applyAdminMenuVisibility = async () => {
            const session = await getAuthSession();
            if (!session?.access_token) {
                if (noticeAdminBtn) noticeAdminBtn.classList.remove('visible');
                setNoticeAdminOpen(false);
                return null;
            }
            const res = await sendRuntimeMessage({ type: 'AUTH_GET_PROFILE' });
            const profile = res.success ? res.profile : null;
            const isAdmin = profile?.role === 'admin';
            if (noticeAdminBtn) noticeAdminBtn.classList.toggle('visible', Boolean(isAdmin));
            if (!isAdmin) setNoticeAdminOpen(false);
            return { session, profile };
        };

        const toggleProfileMenu = async () => {
            if (!profileMenu) return;
            const isOpen = profileMenu.classList.toggle('open');
            profileMenu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
            if (isOpen) await applyAdminMenuVisibility();
        };

        const signOut = async () => {
            closeProfileMenu();
            const res = await sendRuntimeMessage({ type: 'AUTH_SIGN_OUT' });
            if (res.success) {
                updateProfileButton(null);
                addLog('로그아웃되었습니다.');
            } else {
                addLog(`❌ 로그아웃 실패: ${res.error}`);
            }
        };

        const showMyPage = async () => {
            if (myPagePanel?.classList.contains('open')) {
                setMyPageOpen(false);
                return;
            }
            const access = await applyAdminMenuVisibility();
            const session = access?.session;
            const profile = access?.profile;
            if (!session?.access_token) {
                alert('로그인 후 확인할 수 있습니다.');
                return;
            }
            if (!profile) {
                alert('사용자 정보를 불러오지 못했습니다.');
                return;
            }
            const used = profile.role === 'admin'
                ? '관리자'
                : `오늘 ${profile.used_today || 0}/${profile.daily_limit || 0}회`;
            const values = {
                myPageEmail: session.user?.email || '-',
                myPagePlan: profile.plan || '-',
                myPageStatus: profile.status || '-',
                myPageUsage: used
            };
            Object.entries(values).forEach(([id, value]) => {
                const el = document.getElementById(id);
                if (el) el.innerText = value;
            });
            setMyPageOpen(true);
        };

        const renderNoticeAdminList = (items = []) => {
            if (!noticeAdminList) return;
            if (!items.length) {
                noticeAdminList.innerHTML = '<div class="notice-admin-item-meta">등록된 공지가 없습니다.</div>';
                return;
            }
            noticeAdminList.innerHTML = items.map(item => `
                <div class="notice-admin-item" data-id="${item.id}">
                    <div class="notice-admin-item-title">${escapeHtml(item.title)}</div>
                    <div class="notice-admin-item-meta">${item.is_active ? '게시중' : '숨김'} · ${formatNoticeDate(item.starts_at || item.created_at)}</div>
                    <div class="notice-admin-item-actions">
                        <button class="notice-admin-mini" data-action="edit" type="button">수정</button>
                        <button class="notice-admin-mini" data-action="hide" type="button">숨김</button>
                        <button class="notice-admin-mini danger" data-action="delete" type="button">삭제</button>
                    </div>
                </div>
            `).join('');
            noticeAdminList.querySelectorAll('button[data-action]').forEach(btn => {
                btn.onclick = async (event) => {
                    event.stopPropagation();
                    const itemEl = btn.closest('.notice-admin-item');
                    const id = itemEl?.dataset.id;
                    const item = items.find(row => String(row.id) === String(id));
                    const action = btn.dataset.action;
                    if (!id || !item) return;
                    if (action === 'edit') {
                        editingAnnouncementId = id;
                        if (noticeAdminTitle) noticeAdminTitle.value = item.title || '';
                        if (noticeAdminMessage) noticeAdminMessage.value = item.message || '';
                        if (noticeAdminSaveBtn) noticeAdminSaveBtn.innerText = '수정';
                        return;
                    }
                    if (action === 'hide') {
                        const res = await sendRuntimeMessage({ type: 'ANNOUNCEMENT_ADMIN_HIDE', id });
                        if (!res.success) return alert(res.error || '공지 숨김에 실패했습니다.');
                    }
                    if (action === 'delete') {
                        if (!confirm('이 공지를 삭제할까요?')) return;
                        const res = await sendRuntimeMessage({ type: 'ANNOUNCEMENT_ADMIN_DELETE', id });
                        if (!res.success) return alert(res.error || '공지 삭제에 실패했습니다.');
                    }
                    resetNoticeAdminForm();
                    await loadNoticeAdminList();
                    await checkAnnouncement(true);
                };
            });
        };

        const loadNoticeAdminList = async () => {
            const res = await sendRuntimeMessage({ type: 'ANNOUNCEMENT_ADMIN_LIST' });
            if (!res.success) {
                if (noticeAdminList) noticeAdminList.innerHTML = `<div class="notice-admin-item-meta">${escapeHtml(res.error || '공지 목록을 불러오지 못했습니다.')}</div>`;
                return;
            }
            renderNoticeAdminList(res.announcements || []);
        };

        const toggleNoticeAdmin = async () => {
            const isOpen = noticeAdminPanel?.classList.contains('open');
            setNoticeAdminOpen(!isOpen);
            if (!isOpen) await loadNoticeAdminList();
        };

        if (profileMenu) {
            profileMenu.onclick = (event) => event.stopPropagation();
        }

        if (profileLoginBtn) {
            getAuthSession().then(updateProfileButton);
            profileLoginBtn.onclick = async (event) => {
                event.stopPropagation();
                const current = await getAuthSession();
                if (current?.access_token) {
                    await toggleProfileMenu();
                    return;
                }
                closeProfileMenu();
                addLog('Google 로그인 창을 여는 중...');
                const res = await sendRuntimeMessage({ type: 'AUTH_SIGN_IN' });
                if (res.success) {
                    updateProfileButton(res.session);
                    await applyAdminMenuVisibility();
                    addLog('로그인 완료');
                } else {
                    addLog(`❌ 로그인 실패: ${res.error}`);
                    alert(res.error || '로그인에 실패했습니다.');
                }
            };
        }

        if (myPageBtn) {
            myPageBtn.onclick = (event) => {
                event.stopPropagation();
                showMyPage();
            };
        }

        if (noticeAdminBtn) {
            noticeAdminBtn.onclick = (event) => {
                event.stopPropagation();
                toggleNoticeAdmin();
            };
        }

        if (noticeAdminSaveBtn) {
            noticeAdminSaveBtn.onclick = async (event) => {
                event.stopPropagation();
                const title = noticeAdminTitle?.value.trim() || '';
                const message = noticeAdminMessage?.value.trim() || '';
                if (!title || !message) return alert('공지 제목과 내용을 입력하세요.');
                const res = await sendRuntimeMessage({
                    type: 'ANNOUNCEMENT_ADMIN_SAVE',
                    id: editingAnnouncementId,
                    title,
                    message
                });
                if (!res.success) return alert(res.error || '공지 저장에 실패했습니다.');
                resetNoticeAdminForm();
                await loadNoticeAdminList();
                await checkAnnouncement(true);
                alert('공지 저장 완료');
            };
        }

        if (noticeAdminClearBtn) {
            noticeAdminClearBtn.onclick = (event) => {
                event.stopPropagation();
                resetNoticeAdminForm();
            };
        }

        if (logoutBtn) {
            logoutBtn.onclick = (event) => {
                event.stopPropagation();
                signOut();
            };
        }

        const noticeBtn = document.getElementById('noticeBtn');
        const noticeMenu = document.getElementById('noticeMenu');
        const noticeTitle = document.getElementById('noticeTitle');
        const noticeMessage = document.getElementById('noticeMessage');
        const noticeDate = document.getElementById('noticeDate');
        let latestAnnouncement = null;

        const closeNoticeMenu = () => {
            if (!noticeMenu) return;
            noticeMenu.classList.remove('open');
            noticeMenu.setAttribute('aria-hidden', 'true');
        };

        const formatNoticeDate = (value) => {
            if (!value) return '';
            try {
                return new Date(value).toLocaleString('ko-KR', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch (e) {
                return '';
            }
        };

        const renderAnnouncement = async (announcement) => {
            latestAnnouncement = announcement || null;
            if (noticeTitle) noticeTitle.innerText = latestAnnouncement?.title || '공지사항이 없습니다.';
            if (noticeMessage) noticeMessage.innerText = latestAnnouncement?.message || '새 공지가 등록되면 이곳에 표시됩니다.';
            if (noticeDate) noticeDate.innerText = latestAnnouncement ? formatNoticeDate(latestAnnouncement.starts_at || latestAnnouncement.created_at) : '';

            const data = await chrome.storage.local.get('flowAnnouncementReadId');
            const readId = data.flowAnnouncementReadId;
            const hasNew = latestAnnouncement?.id && String(latestAnnouncement.id) !== String(readId || '');
            if (noticeBtn) noticeBtn.classList.toggle('has-new', Boolean(hasNew));
        };

        const checkAnnouncement = async (force = false) => {
            const res = await sendRuntimeMessage({ type: 'ANNOUNCEMENT_GET', force });
            if (res.success) {
                await renderAnnouncement(res.announcement || null);
            } else {
                debugLog(`공지 조회 실패: ${res.error || 'unknown error'}`);
            }
        };

        if (noticeBtn) {
            noticeBtn.onclick = async (event) => {
                event.stopPropagation();
                closeProfileMenu();
                const isOpen = noticeMenu?.classList.toggle('open');
                if (noticeMenu) noticeMenu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
                if (isOpen && latestAnnouncement?.id) {
                    await chrome.storage.local.set({ flowAnnouncementReadId: String(latestAnnouncement.id) });
                    noticeBtn.classList.remove('has-new');
                }
            };
            checkAnnouncement(false);
        }

        document.addEventListener('click', closeNoticeMenu);

        const infoEditBtn = document.getElementById('infoEditBtn');
        const infoEditor = document.getElementById('infoEditor');
        const infoEditBody = document.getElementById('infoEditBody');
        const infoSaveBtn = document.getElementById('infoSaveBtn');
        let currentInfoContent = null;

        const setInfoEditorOpen = (isOpen) => {
            if (!infoEditor) return;
            infoEditor.classList.toggle('open', Boolean(isOpen));
            infoEditor.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
        };

        const linkifyInfoBody = (value) => {
            const escaped = escapeHtml(value || '사이트 소개 및 안내 정보가\n이곳에 표시될 예정입니다.');
            return escaped.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
        };

        const renderInfoContent = (content) => {
            currentInfoContent = content || {
                title: '정보',
                body: '사이트 소개 및 안내 정보가\n이곳에 표시될 예정입니다.'
            };
            const descEl = document.getElementById('info-desc');
            if (descEl) descEl.innerHTML = linkifyInfoBody(currentInfoContent.body);
            if (infoEditBody) infoEditBody.value = currentInfoContent.body || '';
        };

        const loadInfoContent = async () => {
            const res = await sendRuntimeMessage({ type: 'APP_CONTENT_GET', key: 'info' });
            if (res.success) renderInfoContent(res.content);
            const access = await applyAdminMenuVisibility();
            const isAdmin = access?.profile?.role === 'admin';
            if (infoEditBtn) infoEditBtn.classList.toggle('visible', Boolean(isAdmin));
            if (!isAdmin) setInfoEditorOpen(false);
        };

        if (infoEditBtn) {
            infoEditBtn.onclick = async () => {
                if (infoEditor?.classList.contains('open')) {
                    setInfoEditorOpen(false);
                    return;
                }
                if (currentInfoContent) renderInfoContent(currentInfoContent);
                setInfoEditorOpen(true);
            };
        }

        if (infoSaveBtn) {
            infoSaveBtn.onclick = async () => {
                const body = infoEditBody?.value.trim() || '';
                if (!body) return alert('정보 내용을 입력하세요.');
                const res = await sendRuntimeMessage({ type: 'APP_CONTENT_SAVE', key: 'info', title: '정보', body });
                if (!res.success) return alert(res.error || '정보 저장에 실패했습니다.');
                renderInfoContent(res.content);
                setInfoEditorOpen(false);
                alert('정보 저장 완료');
            };
        }

        loadInfoContent();

        // Prompt Count and Scene Preview Update
        const input = document.getElementById('promptInput');
        const assetStorageKey = 'flowReferenceAssets';
        let referenceAssets = [];
        let sceneAssetSelections = {};

        const getPromptScenes = () => input.value.split(/\n\s*\n/).map(v => v.trim()).filter(Boolean);
        const escapeHtml = (value) => String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
        const getSceneKey = (idx) => `scene-${idx}`;

        const setupPromptResize = () => {
            const handle = document.getElementById('promptResizeHandle');
            if (!handle || !input) return;
            chrome.storage.local.get('flowPromptInputHeight', (data) => {
                if (data.flowPromptInputHeight) {
                    input.style.flex = '0 0 auto';
                    input.style.height = `${data.flowPromptInputHeight}px`;
                }
            });
            handle.onmousedown = (e) => {
                e.preventDefault();
                const startY = e.clientY;
                const startHeight = input.getBoundingClientRect().height;
                const onMove = (moveEvent) => {
                    const nextHeight = Math.max(80, Math.min(520, startHeight + (moveEvent.clientY - startY)));
                    input.style.flex = '0 0 auto';
                    input.style.height = `${Math.round(nextHeight)}px`;
                };
                const onUp = () => {
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    chrome.storage.local.set({ flowPromptInputHeight: Math.round(input.getBoundingClientRect().height) });
                };
                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            };
        };
        setupPromptResize();

        const saveReferenceAssets = () => {
            chrome.storage.local.set({
                [assetStorageKey]: {
                    assets: referenceAssets,
                    selections: sceneAssetSelections
                }
            });
        };

        const createAssetThumb = (file) => new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = reject;
            reader.onload = () => {
                const img = new Image();
                img.onerror = () => resolve(reader.result);
                img.onload = () => {
                    const max = 160;
                    const scale = Math.min(1, max / Math.max(img.width, img.height));
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1, Math.round(img.width * scale));
                    canvas.height = Math.max(1, Math.round(img.height * scale));
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    resolve(canvas.toDataURL('image/jpeg', 0.78));
                };
                img.src = reader.result;
            };
            reader.readAsDataURL(file);
        });

        const renderAssetList = () => {
            const empty = document.getElementById('assetEmpty');
            const list = document.getElementById('assetList');
            if (!empty || !list) return;
            const hasAssets = referenceAssets.length > 0;
            empty.style.display = 'none';
            list.style.display = hasAssets ? 'flex' : 'none';
            list.innerHTML = referenceAssets.map(asset => `
                <div class="asset-item" data-asset-id="${escapeHtml(asset.id)}">
                    <img class="asset-thumb" src="${asset.thumb}" alt="">
                    <div class="asset-name" title="${escapeHtml(asset.name)}">${escapeHtml(asset.name)}</div>
                    <button class="asset-remove" type="button" aria-label="이미지 삭제">&times;</button>
                </div>
            `).join('');
        };

        const renderSceneAssets = (prompts) => {
            const list = document.getElementById('sceneAssetList');
            if (!list) return;
            const hasAssets = referenceAssets.length > 0;
            list.style.display = hasAssets && prompts.length ? 'flex' : 'none';
            if (!prompts.length || !hasAssets) {
                list.innerHTML = '';
                return;
            }
            list.innerHTML = prompts.map((prompt, idx) => {
                const sceneKey = getSceneKey(idx);
                const selected = new Set(sceneAssetSelections[sceneKey] || []);
                const assetOptions = hasAssets ? referenceAssets.map(asset => `
                    <label class="scene-asset-chip ${selected.has(asset.id) ? 'selected' : ''}" title="${escapeHtml(asset.name)}">
                        <input type="checkbox" data-scene-key="${sceneKey}" data-asset-id="${escapeHtml(asset.id)}" ${selected.has(asset.id) ? 'checked' : ''}>
                        <img src="${asset.thumb}" alt="">
                        <span>${escapeHtml(asset.name)}</span>
                    </label>
                `).join('') : '';
                return `
                    <div class="scene-card" data-scene-index="${idx}">
                        <div class="scene-title">씬${idx + 1}</div>
                        <div class="scene-preview">${escapeHtml(prompt)}</div>
                        <div class="scene-asset-empty" style="display: ${hasAssets ? 'none' : 'block'};">이미지를 첨부하면 이 씬에 사용할 이미지를 선택할 수 있습니다.</div>
                        <div class="scene-assets" style="display: ${hasAssets ? 'flex' : 'none'};">${assetOptions}</div>
                    </div>
                `;
            }).join('');
        };

        const renderReferenceAssets = () => {
            renderAssetList();
            renderSceneAssets(getPromptScenes());
        };

        const updateCount = () => {
            const prompts = getPromptScenes();
            document.getElementById('promptCount').innerText = `${prompts.length}${t('promptCountSuffix')}`;
            renderSceneAssets(prompts);
        };
        input.oninput = updateCount;

        const assetFileInput = document.getElementById('assetFileInput');
        const addAssetBtn = document.getElementById('addAssetBtn');
        if (addAssetBtn && assetFileInput) {
            addAssetBtn.onclick = () => assetFileInput.click();
        }
        if (assetFileInput) {
            assetFileInput.onchange = async (e) => {
                const files = Array.from(e.target.files || []).filter(file => file.type.startsWith('image/'));
                if (!files.length) return;
                const existing = new Set(referenceAssets.map(asset => `${asset.name}-${asset.size}-${asset.lastModified}`));
                for (const file of files) {
                    const key = `${file.name}-${file.size}-${file.lastModified}`;
                    if (existing.has(key)) continue;
                    const thumb = await createAssetThumb(file);
                    referenceAssets.push({
                        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                        name: file.name,
                        size: file.size,
                        type: file.type,
                        lastModified: file.lastModified,
                        thumb
                    });
                    existing.add(key);
                }
                e.target.value = '';
                saveReferenceAssets();
                renderReferenceAssets();
            };
        }

        const assetList = document.getElementById('assetList');
        if (assetList) {
            assetList.onclick = (e) => {
                const removeBtn = e.target.closest('.asset-remove');
                if (!removeBtn) return;
                const item = removeBtn.closest('.asset-item');
                const assetId = item?.dataset.assetId;
                referenceAssets = referenceAssets.filter(asset => asset.id !== assetId);
                for (const sceneKey of Object.keys(sceneAssetSelections)) {
                    sceneAssetSelections[sceneKey] = (sceneAssetSelections[sceneKey] || []).filter(id => id !== assetId);
                }
                saveReferenceAssets();
                renderReferenceAssets();
            };
        }

        const clearAssetSelectionBtn = document.getElementById('clearAssetSelectionBtn');
        if (clearAssetSelectionBtn) {
            clearAssetSelectionBtn.onclick = () => {
                sceneAssetSelections = {};
                saveReferenceAssets();
                renderReferenceAssets();
            };
        }

        const sceneAssetList = document.getElementById('sceneAssetList');
        if (sceneAssetList) {
            sceneAssetList.onchange = (e) => {
                const checkbox = e.target.closest('input[type="checkbox"][data-scene-key]');
                if (!checkbox) return;
                const sceneKey = checkbox.dataset.sceneKey;
                const assetId = checkbox.dataset.assetId;
                const selected = new Set(sceneAssetSelections[sceneKey] || []);
                checkbox.checked ? selected.add(assetId) : selected.delete(assetId);
                checkbox.closest('.scene-asset-chip')?.classList.toggle('selected', checkbox.checked);
                sceneAssetSelections[sceneKey] = Array.from(selected);
                saveReferenceAssets();
            };
        }

        chrome.storage.local.get(assetStorageKey, (data) => {
            const saved = data[assetStorageKey] || {};
            referenceAssets = Array.isArray(saved.assets) ? saved.assets : [];
            sceneAssetSelections = saved.selections || {};
            renderReferenceAssets();
        });
        updateCount();

        // Clear & Import
        document.getElementById('clearBtn').onclick = () => { input.value = ''; updateCount(); };
        document.getElementById('importBtn').onclick = () => document.getElementById('fileInput').click();
        document.getElementById('fileInput').onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                input.value = (input.value.trim() ? input.value + '\n' : '') + ev.target.result;
                updateCount();
            };
            reader.readAsText(file);
            e.target.value = '';
        };

        // Language Switch
        document.getElementById('languageSelect').onchange = (e) => {
            applyLanguage(e.target.value);
        };

        // Settings Synchronization
        // Model Sync
        const modelSelects = document.querySelectorAll('.sync-model');
        modelSelects.forEach(sel => {
            sel.onchange = (e) => {
                modelSelects.forEach(s => s.value = e.target.value);
            };
        });

        // Ratio & Count Sync
        ['sync-flow-mode', 'sync-ratio', 'sync-count'].forEach(cls => {
            const containers = document.querySelectorAll('.' + cls);
            containers.forEach(container => {
                container.onclick = (e) => {
                    const btn = e.target.closest('.seg-btn');
                    if (btn) {
                        const val = btn.dataset.val;
                        // Update all containers with this class
                        document.querySelectorAll('.' + cls).forEach(c => {
                            c.querySelectorAll('.seg-btn').forEach(b => {
                                b.classList.toggle('active', b.dataset.val === val);
                            });
                        });
                    }
                };
            });
        });

        // Save Settings
        document.getElementById('saveSettingsBtn').onclick = () => {
            saveSettings();
        };

        // Page Check & Go to FLOW
        const checkCurrentPage = async () => {
            const overlay = document.getElementById('wrongPageOverlay');
            const connectionBadge = document.getElementById('flowConnectionBadge');
            if (!overlay) return;
            
            try {
                const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                const tab = tabs[0];
                const url = tab?.url || "";
                
                if (isFlowUrl(url)) {
                    overlay.style.display = 'none';
                    if (connectionBadge) connectionBadge.style.display = 'inline-flex';
                } else {
                    overlay.style.display = 'flex';
                    if (connectionBadge) connectionBadge.style.display = 'none';
                }
            } catch (e) {
                console.error("Page check error:", e);
                // 오류 발생 시 일단 가림 (사용자 경험 우선)
                overlay.style.display = 'none';
                if (connectionBadge) connectionBadge.style.display = 'none';
            }
        };

        document.getElementById('goToFlowBtn').onclick = () => {
            chrome.tabs.create({ url: 'https://labs.google/fx/ko/tools/flow' });
        };

        // Initial check
        checkCurrentPage();

        // Listen for tab changes
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
            if (changeInfo.status === 'complete') checkCurrentPage();
        });
        chrome.tabs.onActivated.addListener(() => checkCurrentPage());
    };

    const saveSettings = () => {
        const config = {
            lang: document.getElementById('languageSelect').value,
            flowMode: document.querySelector('.sync-flow-mode .active')?.dataset.val || 'normal',
            model: document.querySelector('.sync-model').value,
            ratio: document.querySelector('.sync-ratio .active').dataset.val,
            count: document.querySelector('.sync-count .active').dataset.val,
            autoDl: document.getElementById('auto-download').checked,
            waitTime: parseInt(document.getElementById('wait-time').value) || 40,
            retryCount: document.getElementById('retry-count').value !== "" ? parseInt(document.getElementById('retry-count').value) : 3,
            delayTime: parseFloat(document.getElementById('delay-time').value) || 2.0
        };
        chrome.storage.local.set({ 'flowAutomationSettings': config }, () => {
            addLog(t('logSettingsSaved'));
            alert(t('alertSettingsSaved'));
        });
    };

    const loadSettings = () => {
        chrome.storage.local.get('flowAutomationSettings', (data) => {
            let cfg = {
                lang: 'ko',
                flowMode: 'normal',
                model: 'Nano Banana Pro',
                ratio: '16:9',
                count: '1',
                autoDl: false,
                waitTime: 40,
                retryCount: 3,
                delayTime: 2.0
            };

            if (data.flowAutomationSettings) {
                cfg = { ...cfg, ...data.flowAutomationSettings };
            }
            const supportedModels = ['Nano Banana Pro', 'Nano Banana 2', 'Nano Banana 2 Lite'];
            if (!supportedModels.includes(cfg.model)) cfg.model = 'Nano Banana Pro';

            // Apply Language first
            document.getElementById('languageSelect').value = cfg.lang;
            applyLanguage(cfg.lang);
            addLog(t('logSystemReady'));

            // Sync UI with loaded settings
            // Sync Flow Mode
            document.querySelectorAll('.sync-flow-mode').forEach(c => {
                c.querySelectorAll('.seg-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.val === (cfg.flowMode || 'normal'));
                });
            });

            // Sync Model
            document.querySelectorAll('.sync-model').forEach(s => s.value = cfg.model);
            
            // Sync Ratio
            document.querySelectorAll('.sync-ratio').forEach(c => {
                c.querySelectorAll('.seg-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.val === cfg.ratio);
                });
            });
            
            // Sync Count
            document.querySelectorAll('.sync-count').forEach(c => {
                c.querySelectorAll('.seg-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.val === cfg.count);
                });
            });

            // Advanced settings
            document.getElementById('auto-download').checked = cfg.autoDl;
            document.getElementById('wait-time').value = cfg.waitTime;
            document.getElementById('retry-count').value = cfg.retryCount;
            document.getElementById('delay-time').value = (cfg.delayTime || 2.0).toFixed(1);

            addLog("🔧 버전: V3.2");
        });
    };

    const DEBUG_LOGS = false;

    const addLog = (msg) => {
        const logArea = document.getElementById('logArea');
        if (logArea) {
            const time = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
            const div = document.createElement('div');
            div.style.marginBottom = '4px';
            div.innerHTML = `<span style="color: var(--text-dim)">[${time}]</span> ${msg}`;
            logArea.appendChild(div);
            logArea.scrollTop = logArea.scrollHeight;
        }
    };

    const debugLog = (msg) => {
        if (DEBUG_LOGS) addLog(msg);
    };

    const wait = (ms) => new Promise(r => setTimeout(r, ms));

    const getFlowTab = () => new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'GET_FLOW_TAB' }, (res) => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            if (!res || !res.tab) return reject(new Error("Google Flow 탭을 찾을 수 없습니다.\nlabs.google 페이지를 먼저 열어주세요."));
            resolve(res.tab);
        });
    });


    const sendRuntimeMessage = (payload) => new Promise((resolve) => {
        chrome.runtime.sendMessage(payload, (res) => {
            if (chrome.runtime.lastError) {
                resolve({ success: false, error: chrome.runtime.lastError.message });
            } else {
                resolve(res || { success: false, error: '응답이 없습니다.' });
            }
        });
    });

    const updateProfileButton = (session) => {
        const btn = document.getElementById('profileLoginBtn');
        if (!btn) return;
        const email = session?.user?.email;
        btn.dataset.loggedIn = email ? 'true' : 'false';
        btn.style.color = email ? 'var(--success)' : 'var(--text-dim)';
        btn.setAttribute('title', email ? '프로필 메뉴' : '로그인');
        btn.setAttribute('aria-label', email ? '프로필 메뉴 열기' : '로그인');
        const menuEmail = document.getElementById('profileMenuEmail');
        if (menuEmail) menuEmail.innerText = email || '';
        const menu = document.getElementById('profileMenu');
        if (!email && menu) {
            menu.classList.remove('open');
            menu.setAttribute('aria-hidden', 'true');
        }
        const myPagePanel = document.getElementById('myPagePanel');
        if (!email && myPagePanel) {
            myPagePanel.classList.remove('open');
            myPagePanel.setAttribute('aria-hidden', 'true');
        }
        const noticeAdminBtn = document.getElementById('noticeAdminBtn');
        const noticeAdminPanel = document.getElementById('noticeAdminPanel');
        if (!email && noticeAdminBtn) noticeAdminBtn.classList.remove('visible');
        if (!email && noticeAdminPanel) {
            noticeAdminPanel.classList.remove('open');
            noticeAdminPanel.setAttribute('aria-hidden', 'true');
        }
    };

    const getAuthSession = async () => {
        const res = await sendRuntimeMessage({ type: 'AUTH_GET_SESSION' });
        return res.success ? res.session : null;
    };

    const requireAuthSession = async () => {
        const session = await getAuthSession();
        updateProfileButton(session);
        if (!session?.access_token) {
            alert('로그인 후 사용할 수 있습니다. 우측 상단 프로필 아이콘을 눌러 로그인하세요.');
            return null;
        }
        return session;
    };

    const hasSelectedReferenceImages = async (promptCount) => {
        const data = await chrome.storage.local.get('flowReferenceAssets');
        const saved = data.flowReferenceAssets || {};
        const selections = saved.selections || {};
        for (let i = 0; i < promptCount; i += 1) {
            const selectedIds = selections[`scene-${i}`] || [];
            if (Array.isArray(selectedIds) && selectedIds.length > 0) return true;
        }
        return false;
    };

    const requireUserAccess = async ({ units = 1, promptCount = 1, usesReferenceImages = false } = {}) => {
        const session = await requireAuthSession();
        if (!session) return null;

        const profileRes = await sendRuntimeMessage({ type: 'AUTH_GET_PROFILE' });
        if (!profileRes.success || !profileRes.profile) {
            const rawError = profileRes.error || '';
            alert(`사용자 권한 정보가 없습니다. 관리자 승인 후 사용할 수 있습니다.${rawError ? `

${rawError}` : ''}`);
            return null;
        }

        const currentProfile = profileRes.profile;
        if (currentProfile.status !== 'active') {
            const messages = {
                pending: '관리자 승인 대기 중입니다.',
                blocked: '차단된 계정입니다. 관리자에게 문의하세요.',
                expired: '사용 기간이 만료되었습니다.'
            };
            alert(messages[currentProfile.status] || '사용할 수 없는 계정 상태입니다.');
            return null;
        }
        if (currentProfile.expires_at && new Date(currentProfile.expires_at).getTime() < Date.now()) {
            alert('사용 기간이 만료되었습니다.');
            return null;
        }

        const isAdmin = currentProfile.role === 'admin';
        if (!isAdmin && promptCount > 1 && !currentProfile.allow_multi_prompt) {
            alert('다중 프롬프트 권한이 없습니다. 관리자에게 문의하세요.');
            return null;
        }
        if (!isAdmin && usesReferenceImages && !currentProfile.allow_reference_image) {
            alert('참조 이미지 권한이 없습니다. 관리자에게 문의하세요.');
            return null;
        }

        const res = await sendRuntimeMessage({ type: 'AUTH_CONSUME_USAGE', units });
        if (!res.success) {
            const errorMap = {
                PROFILE_NOT_FOUND: '사용자 권한 정보가 없습니다. 관리자 승인 후 사용할 수 있습니다.',
                ACCOUNT_EXPIRED: '사용 기간이 만료되었습니다.',
                DAILY_LIMIT_EXCEEDED: '오늘 사용 가능 횟수를 모두 사용했습니다.',
                MONTHLY_LIMIT_EXCEEDED: '이번 달 사용 가능 횟수를 모두 사용했습니다.'
            };
            const rawError = res.error || '';
            const knownKey = Object.keys(errorMap).find(key => rawError.includes(key));
            alert(knownKey ? errorMap[knownKey] : `권한 또는 사용량을 확인하지 못했습니다.

${rawError}`);
            return null;
        }
        const profile = res.profile;
        if (!profile) {
            alert('사용자 권한 정보가 없습니다. 관리자 승인 후 사용할 수 있습니다.');
            return null;
        }
        if (profile.role === 'admin') {
            addLog('관리자 권한 확인 완료');
        } else {
            addLog(`권한 확인 완료: 오늘 ${profile.used_today}/${profile.daily_limit || '∞'}회 사용`);
        }
        return { session: res.session || session, profile };
    };

    const initAutomation = () => {
        const startBtn = document.getElementById('startBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const stopBtn = document.getElementById('stopBtn');

        pauseBtn.onclick = () => {
            if (isRunning && !isPaused) {
                isPaused = true;
                addLog("⏸ 일시정지 요청됨. 현재 작업 완료 후 멈춥니다.");
                pauseBtn.innerText = "정지 중...";
                pauseBtn.disabled = true;
            }
        };

        stopBtn.onclick = () => {
            if (isRunning) {
                isRunning = false;
                isPaused = false;
                addLog("🛑 중지 요청됨. 즉시 중단합니다.");
                stopBtn.disabled = true;
                pauseBtn.disabled = true;
                startBtn.disabled = false;
                startBtn.innerText = "자동화 시작";
                document.getElementById('statusArea').style.display = 'none';
            }
        };

        startBtn.onclick = async () => {
            const inputVal = document.getElementById('promptInput').value;
            const prompts = inputVal.split(/\n\s*\n/).filter(l => l.trim() !== '');

            if (prompts.length === 0) return alert('프롬프트를 입력하세요.');

            const authAccess = await requireUserAccess({
                units: prompts.length,
                promptCount: prompts.length,
                usesReferenceImages: await hasSelectedReferenceImages(prompts.length)
            });
            if (!authAccess) return;

            // 만약 이미 실행 중인데 일시정지 상태였다면 재개
            if (isRunning && isPaused) {
                isPaused = false;
                pauseBtn.innerText = "일시정지";
                pauseBtn.disabled = false;
                startBtn.disabled = true;
                addLog("▶ 작업을 재개합니다.");
                return;
            }

            if (isRunning) return;

            let tab;
            try { 
                tab = await getFlowTab(); 
                document.getElementById('connectedTabUrl').innerText = tab.url.split('?')[0];
            }
            catch (e) { 
                addLog(`❌ 오류: ${e.message}`);
                return alert("Google Flow 탭을 찾을 수 없습니다.\n\n1. labs.google/fx/.../tools/flow 페이지를 열어주세요.\n2. 탭이 이미 열려있다면 새로고침 후 다시 시도해주세요."); 
            }

            isRunning = true;
            isPaused = false;
            currentPromptIndex = 0;
            startBtn.disabled = true;
            pauseBtn.disabled = false;
            pauseBtn.innerText = "일시정지";
            stopBtn.disabled = false;
            document.getElementById('statusArea').style.display = 'block';
            addLog(`🚀 엔진 가동! 총 ${prompts.length}개의 작업을 시작합니다.`);

            const config = {
                flowMode: document.querySelector('.sync-flow-mode .active')?.dataset.val || 'normal',
                model: document.querySelector('.sync-model').value,
                ratio: document.querySelector('.sync-ratio .active').dataset.val,
                count: document.querySelector('.sync-count .active').dataset.val,
                autoDl: document.getElementById('auto-download').checked,
                waitTime: parseInt(document.getElementById('wait-time').value) || 40,
                retryCount: document.getElementById('retry-count').value !== "" ? parseInt(document.getElementById('retry-count').value) : 3,
                delayTime: parseFloat(document.getElementById('delay-time').value) || 2.0
            };

            const debuggerClick = (point) => new Promise((resolve) => {
                chrome.runtime.sendMessage({
                    type: 'DEBUGGER_CLICK',
                    tabId: tab.id,
                    x: point.x,
                    y: point.y
                }, (res) => {
                    if (chrome.runtime.lastError) {
                        resolve({ success: false, error: chrome.runtime.lastError.message });
                    } else {
                        resolve(res || { success: false, error: 'No debugger response' });
                    }
                });
            });

            const getSceneReferenceAssets = async (sceneIndex) => {
                const data = await chrome.storage.local.get('flowReferenceAssets');
                const saved = data.flowReferenceAssets || {};
                const assets = Array.isArray(saved.assets) ? saved.assets : [];
                const selections = saved.selections || {};
                const selectedIds = new Set(selections[`scene-${sceneIndex}`] || []);
                return assets
                    .filter(asset => selectedIds.has(asset.id))
                    .map(asset => ({ id: asset.id, name: asset.name }));
            };

            const waitForGenerationStart = async () => {
                const check = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: async () => {
                        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                        const isVisible = (el) => {
                            if (!el) return false;
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
                        };
                        const isStarted = () => {
                            const buttons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(isVisible);
                            const hasStopBtn = buttons.some(b => {
                                const joined = `${b.getAttribute('aria-label') || ''} ${b.getAttribute('title') || ''} ${b.innerText || ''}`.toLowerCase();
                                return joined.includes('stop') || joined.includes('중지');
                            });
                            const bodyText = document.body.innerText.toLowerCase();
                            return hasStopBtn || bodyText.includes('generating') || bodyText.includes('creating') ||
                                bodyText.includes('생성 중') || bodyText.includes('만드는 중') || bodyText.includes('처리 중');
                        };

                        for (let i = 0; i < 40; i++) {
                            await sleep(200);
                            if (isStarted()) return true;
                        }
                        return false;
                    }
                });
                return Boolean(check[0]?.result);
            };

            const findGenerationClickPoint = async () => {
                const result = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: async () => {
                        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                        const isVisible = (el) => {
                            if (!el) return false;
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
                        };
                        const findPromptEditorRect = () => {
                            const selectors = [
                                '[data-slate-editor="true"]',
                                '[contenteditable="true"][role="textbox"]',
                                '[contenteditable="true"]',
                                'textarea[placeholder]',
                                'textarea'
                            ];
                            const candidates = selectors.flatMap(selector => Array.from(document.querySelectorAll(selector)))
                                .filter(isVisible)
                                .map(el => ({ el, rect: el.getBoundingClientRect() }))
                                .filter(item => item.rect.top > window.innerHeight * 0.45 && item.rect.left < window.innerWidth * 0.82)
                                .sort((a, b) => (b.rect.width * b.rect.height) - (a.rect.width * a.rect.height));
                            return candidates[0]?.rect || null;
                        };

                        const isSettingsSaveVisible = () => Array.from(document.querySelectorAll('button'))
                            .filter(isVisible)
                            .some(btn => (btn.innerText || '').replace(/\s/g, '') === '저장');

                        const collect = () => {
                            const promptRect = findPromptEditorRect();
                            const buttons = Array.from(document.querySelectorAll('button, [role="button"], [aria-label]')).filter(isVisible);
                            return buttons.map((b, index) => {
                                const r = b.getBoundingClientRect();
                                const text = `${b.getAttribute('aria-label') || ''} ${b.getAttribute('title') || ''} ${b.innerText || ''} ${b.innerHTML || ''}`.toLowerCase();
                                const hasArrowForward = text.includes('arrow_forward') || text.includes('send') || text.includes('submit');
                                const isArrowForwardIos = text.includes('arrow_forward_ios');
                                const hasGenerateSignal = hasArrowForward &&
                                    (text.includes('만들기') || text.includes('generate') || text.includes('생성') ||
                                    text.includes('arrow_forward') || text.includes('send') || text.includes('submit'));
                                let score = 0;
                                if (!hasGenerateSignal || b.tagName.toLowerCase() !== 'button') score -= 1000;
                                if (isArrowForwardIos) score -= 1000;
                                if (text.includes('add_2') || text.includes('미디어 추가')) score -= 1000;
                                const rightPanelCutoff = Math.max(window.innerWidth * 0.86, window.innerWidth - 180);
                                if (r.left > rightPanelCutoff) score -= 1000;
                                if (text.includes('만들기') || text.includes('generate') || text.includes('생성')) score += 90;
                                if (text.includes('arrow_forward') || text.includes('send') || text.includes('submit')) score += 55;
                                if (text.includes('설정') || text.includes('tune') || text.includes('펼치기') || text.includes('expand_content') || text.includes('닫기') || text.includes('close')) score -= 100;
                                if (b.disabled || b.getAttribute('aria-disabled') === 'true') score -= 100;
                                if (promptRect) {
                                    const dx = Math.abs(r.right - promptRect.right);
                                    const dy = Math.abs((r.top + r.height / 2) - (promptRect.top + promptRect.height / 2));
                                    score += 180 - Math.min(dx / 2, 120) - Math.min(dy * 3, 120);
                                    if (r.left >= promptRect.left && r.top >= promptRect.top - 80 && r.bottom <= promptRect.bottom + 120) score += 80;
                                    if (r.left > promptRect.right + 180) score -= 160;
                                } else {
                                    score += Math.min(r.top / 10, 80);
                                    score -= Math.max(r.left - window.innerWidth * 0.75, 0) / 2;
                                }
                                return {
                                    index,
                                    score,
                                    text: (b.innerText || b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim(),
                                    disabled: Boolean(b.disabled || b.getAttribute('aria-disabled') === 'true'),
                                    rect: {
                                        x: Math.round(r.x),
                                        y: Math.round(r.y),
                                        w: Math.round(r.width),
                                        h: Math.round(r.height)
                                    }
                                };
                            }).sort((a, b) => b.score - a.score);
                        };

                        for (let i = 0; i < 120; i++) {
                            if (i < 8 || isSettingsSaveVisible()) {
                                await sleep(250);
                                continue;
                            }
                            const best = collect().find(item => item.score >= 50 && !item.disabled) ||
                                collect().find(item =>
                                    item.score > -200 &&
                                    item.text.includes('만들기') &&
                                    item.text.includes('arrow_forward') &&
                                    !item.text.includes('add_2') &&
                                    !item.disabled &&
                                    item.rect.x < Math.max(window.innerWidth * 0.86, window.innerWidth - 180) &&
                                    item.rect.y > window.innerHeight * 0.45
                                );
                            if (best) {
                                return {
                                    point: {
                                        x: Math.round(best.rect.x + best.rect.w / 2),
                                        y: Math.round(best.rect.y + best.rect.h / 2)
                                    },
                                    diagnostic: `#${best.index} score=${Math.round(best.score)} "${best.text}" rect=${best.rect.x},${best.rect.y},${best.rect.w},${best.rect.h}`
                                };
                            }
                            await sleep(250);
                        }
                        return { point: null, diagnostic: collect().slice(0, 6).map(item => `#${item.index} score=${Math.round(item.score)} "${item.text}" rect=${item.rect.x},${item.rect.y},${item.rect.w},${item.rect.h}`).join(' | ') };
                    }
                });
                return result[0]?.result || { point: null, diagnostic: 'no response' };
            };

            const waitForPromptEditorReady = async () => {
                const result = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: async () => {
                        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                        const isVisible = (el) => {
                            if (!el) return false;
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
                        };
                        const findEditor = () => {
                            const selectors = [
                                '[data-slate-editor="true"]',
                                '[contenteditable="true"][role="textbox"]',
                                '[contenteditable="true"]',
                                'textarea[placeholder]',
                                'textarea'
                            ];
                            return selectors.flatMap(selector => Array.from(document.querySelectorAll(selector)))
                                .filter(isVisible)
                                .map(el => ({ el, rect: el.getBoundingClientRect() }))
                                .filter(item => item.rect.top > window.innerHeight * 0.45 && item.rect.left < window.innerWidth * 0.82)
                                .sort((a, b) => (b.rect.width * b.rect.height) - (a.rect.width * a.rect.height))[0];
                        };

                        for (let i = 0; i < 120; i++) {
                            const editor = findEditor();
                            if (editor) {
                                return {
                                    ready: true,
                                    rect: {
                                        x: Math.round(editor.rect.x),
                                        y: Math.round(editor.rect.y),
                                        w: Math.round(editor.rect.width),
                                        h: Math.round(editor.rect.height)
                                    }
                                };
                            }
                            await sleep(500);
                        }
                        return { ready: false };
                    }
                });
                return result[0]?.result || { ready: false };
            };

            const findAnyVisibleGenerateClickPoint = async () => {
                const result = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: async () => {
                        const isVisible = (el) => {
                            if (!el) return false;
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0 && r.top > 0 && getComputedStyle(el).visibility !== 'hidden';
                        };
                        const rightPanelCutoff = Math.max(window.innerWidth * 0.86, window.innerWidth - 180);
                        const candidates = Array.from(document.querySelectorAll('button'))
                            .filter(isVisible)
                            .map((btn, index) => {
                                const r = btn.getBoundingClientRect();
                                const text = `${btn.getAttribute('aria-label') || ''} ${btn.getAttribute('title') || ''} ${btn.innerText || ''} ${btn.innerHTML || ''}`.toLowerCase();
                                const disabled = Boolean(btn.disabled || btn.getAttribute('aria-disabled') === 'true');
                                const isGenerate = text.includes('arrow_forward') && text.includes('만들기') &&
                                    !text.includes('arrow_forward_ios') &&
                                    !text.includes('add_2') &&
                                    !text.includes('expand_content') &&
                                    !text.includes('tune') &&
                                    r.left < rightPanelCutoff;
                                return {
                                    index,
                                    isGenerate,
                                    disabled,
                                    text: (btn.innerText || btn.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim(),
                                    rect: {
                                        x: Math.round(r.x),
                                        y: Math.round(r.y),
                                        w: Math.round(r.width),
                                        h: Math.round(r.height)
                                    }
                                };
                            })
                            .sort((a, b) => {
                                const ay = a.rect.y;
                                const by = b.rect.y;
                                if (Math.abs(by - ay) > 40) return by - ay;
                                return a.rect.x - b.rect.x;
                            });
                        const best = candidates.find(item => item.isGenerate && !item.disabled);
                        if (!best) {
                            return {
                                point: null,
                                diagnostic: `cutoff=${Math.round(rightPanelCutoff)} ` + candidates.slice(0, 8).map(item => `#${item.index} gen=${item.isGenerate} disabled=${item.disabled} "${item.text}" rect=${item.rect.x},${item.rect.y},${item.rect.w},${item.rect.h}`).join(' | ')
                            };
                        }
                        return {
                            point: {
                                x: Math.round(best.rect.x + best.rect.w / 2),
                                y: Math.round(best.rect.y + best.rect.h / 2)
                            },
                            diagnostic: `cutoff=${Math.round(rightPanelCutoff)} #${best.index} "${best.text}" rect=${best.rect.x},${best.rect.y},${best.rect.w},${best.rect.h}`
                        };
                    }
                });
                return result[0]?.result || { point: null, diagnostic: 'no response' };
            };

            const configureOpenSettingsSidebar = async () => {
                const result = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    world: 'MAIN',
                    func: async (cfg) => {
                        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                        const log = [];
                        const isVisible = (el) => {
                            if (!el) return false;
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
                        };
                        const click = (el) => {
                            if (!el) return;
                            el.scrollIntoView({ block: 'center', inline: 'center' });
                            const r = el.getBoundingClientRect();
                            const opts = {
                                bubbles: true,
                                cancelable: true,
                                composed: true,
                                view: window,
                                button: 0,
                                buttons: 1,
                                clientX: Math.round(r.left + r.width / 2),
                                clientY: Math.round(r.top + r.height / 2)
                            };
                            el.dispatchEvent(new PointerEvent('pointerdown', opts));
                            el.dispatchEvent(new MouseEvent('mousedown', opts));
                            if (typeof el.focus === 'function') el.focus();
                            el.dispatchEvent(new PointerEvent('pointerup', opts));
                            el.dispatchEvent(new MouseEvent('mouseup', opts));
                            el.dispatchEvent(new MouseEvent('click', opts));
                        };

                        const settingItems = Array.from(document.querySelectorAll('button, [role="tab"], [role="menuitem"], [role="option"]'))
                            .filter(isVisible)
                            .slice(0, 40)
                            .map(el => (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim())
                            .filter(Boolean)
                            .join(' | ');

                        const targetModelName = cfg.model.split('(')[0].trim().toLowerCase();
                        const isTargetModel = (el) => (el.innerText || '').toLowerCase().includes(targetModelName);
                        let modelItem = Array.from(document.querySelectorAll('[role="menuitem"], button'))
                            .filter(isVisible)
                            .find(isTargetModel);

                        if (!modelItem) {
                            const modelBtn = Array.from(document.querySelectorAll('button, [role="button"]'))
                                .filter(isVisible)
                                .find(el => {
                                    const txt = (el.innerText || '').toLowerCase();
                                    const role = el.getAttribute('role') || '';
                                    return role !== 'tab' && (txt.includes('banana') || txt.includes('nano') || txt.includes('모델'));
                                });
                            if (modelBtn) {
                                click(modelBtn);
                                await sleep((cfg.delayTime || 2.0) * 1000);
                                modelItem = Array.from(document.querySelectorAll('[role="menuitem"], button'))
                                    .filter(isVisible)
                                    .find(isTargetModel);
                            }
                        }

                        if (modelItem) {
                            click(modelItem);
                            await sleep((cfg.delayTime || 2.0) * 1000);
                            log.push(`모델 선택: ${cfg.model}`);
                        } else {
                            log.push(`모델 항목을 찾지 못함: ${cfg.model}`);
                        }

                        const allTabs = Array.from(document.querySelectorAll('[role="tab"]')).filter(isVisible);
                        const targetRatioTab = allTabs.find(t => t.innerText.replace(/\s/g, '').includes(cfg.ratio));
                        if (targetRatioTab && targetRatioTab.getAttribute('data-state') !== 'active') {
                            click(targetRatioTab);
                            await sleep(((cfg.delayTime || 2.0) * 1000) / 2);
                            log.push(`비율 선택: ${cfg.ratio}`);
                        }

                        const targetCountTab = allTabs.find(t => {
                            const tabText = t.innerText.replace(/\s/g, '').toLowerCase();
                            const ariaControls = t.getAttribute('aria-controls') || '';
                            const id = t.getAttribute('id') || '';
                            const countKey = String(cfg.count);
                            return tabText === `x${countKey}` || tabText === `${countKey}x` ||
                                ariaControls.endsWith(`content-${countKey}`) || id.endsWith(`trigger-${countKey}`);
                        });
                        if (targetCountTab && targetCountTab.getAttribute('data-state') !== 'active') {
                            click(targetCountTab);
                            await sleep(((cfg.delayTime || 2.0) * 1000) / 2);
                            log.push(`수량 선택: x${cfg.count}`);
                        }

                        const saveBtn = Array.from(document.querySelectorAll('button'))
                            .filter(isVisible)
                            .find(btn => (btn.innerText || "").replace(/\s/g, '') === '저장');
                        if (!saveBtn) {
                            log.push("설정 저장 버튼을 찾지 못함");
                            return { success: false, log };
                        }
                        const r = saveBtn.getBoundingClientRect();
                        log.push(`설정 저장 클릭: rect=${Math.round(r.x)},${Math.round(r.y)},${Math.round(r.width)},${Math.round(r.height)}`);
                        click(saveBtn);
                        await sleep((cfg.delayTime || 2.0) * 1000);
                        return { success: true, log };
                    },
                    args: [config]
                });
                return result[0]?.result || { success: false, log: ['옵션 설정 스크립트 응답 없음'] };
            };

            try {
                for (; currentPromptIndex < prompts.length; currentPromptIndex++) {
                    if (!isRunning) break;

                    const currentPrompt = prompts[currentPromptIndex];
                    const sceneReferenceAssets = await getSceneReferenceAssets(currentPromptIndex);
                    let success = false;
                    let settingsFallbackUsed = false;
                    let settingsApplied = false;

                    // 파일명 지정을 위한 프롬프트 저장
                    await chrome.storage.local.set({ dlPrefix: currentPrompt, autoDl: config.autoDl });

                    for (let attempt = 0; attempt <= config.retryCount; attempt++) {
                        if (!isRunning) break;
                        
                        if (attempt > 0) {
                            addLog(`🔄 [재시도 ${attempt}/${config.retryCount}] 작업을 다시 시도합니다...`);
                            await wait(2000);
                        }

                        // 일시정지 체크 및 대기
                        if (isPaused) {
                            addLog("⏸ 작업이 일시 정지되었습니다. '자동화 재개'를 누르면 이어서 진행합니다.");
                            startBtn.disabled = false;
                            startBtn.innerText = "자동화 재개";
                            
                            while (isPaused && isRunning) {
                                await wait(500);
                            }
                            
                            if (!isRunning) break;

                            startBtn.disabled = true;
                            startBtn.innerText = "자동화 시작";
                            addLog("▶ 작업을 재개합니다.");
                        }

                        const pct = Math.round(((currentPromptIndex + 1) / prompts.length) * 100);
                        document.getElementById('progressBar').style.width = pct + '%';
                        document.getElementById('progressPercent').innerText = pct + '%';
                        document.getElementById('statusMsg').innerText = `작업 중 (${currentPromptIndex + 1}/${prompts.length})`;
                        
                        if (currentPromptIndex > 0 || attempt > 0) {
                            debugLog("⏳ 하단 프롬프트 입력창 복귀 대기 중...");
                            const editorReady = await waitForPromptEditorReady();
                            if (editorReady.ready) {
                                debugLog(`✅ 입력창 복귀 확인 (${editorReady.rect.x}, ${editorReady.rect.y}, ${editorReady.rect.w}, ${editorReady.rect.h})`);
                            } else {
                                debugLog("⚠️ 입력창 복귀를 확인하지 못했습니다. 주입을 시도합니다.");
                            }
                        }

                        addLog(`[${currentPromptIndex + 1}/${prompts.length}] 주입: "${currentPrompt.substring(0, 30)}..."`);
                        if (sceneReferenceAssets.length) {
                            addLog(`🖼 참조 이미지 ${sceneReferenceAssets.length}개 준비`);
                        }

                    // ── MAIN WORLD 스크립트 주입 ──────────────────────────────────
                    const result = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        world: 'MAIN',
                        func: async (text, cfg) => {
                            const log = (m) => console.log(`[FlowMaster] ${m}`);
                            const settingsLog = [];
                            const recordSetting = (m) => {
                                settingsLog.push(m);
                                log(m);
                            };
                            log("자동화 스크립트 실행 시작");
                            
                            // 안전 장치: 현재 URL 확인
                            const url = window.location.href;
                            const cleanUrl = url.split('?')[0].split('#')[0];
                            const isMainPage = cleanUrl.endsWith('/flow') || cleanUrl.endsWith('/flow/');
                            const isFlowUrl = (targetUrl) => {
                                if (!targetUrl) return false;
                                try {
                                    const parsed = new URL(targetUrl);
                                    return parsed.hostname === 'labs.google' &&
                                        parsed.pathname.includes('/fx/') &&
                                        parsed.pathname.includes('/tools/flow');
                                } catch (e) {
                                    return targetUrl.includes('labs.google') && targetUrl.includes('/tools/flow');
                                }
                            };
                            
                            if (!isFlowUrl(url)) {
                                return { success: false, error: "Google Flow 페이지가 아닙니다. 탭을 확인해주세요." };
                            }

                            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                            const dMs = (cfg.delayTime || 2.0) * 1000; // 지연 시간 (ms)
                            
                            const simulateClick = (el) => {
                                if (!el) return;
                                el.scrollIntoView({ block: 'center', inline: 'center' });
                                const r = el.getBoundingClientRect();
                                const clientX = Math.round(r.left + r.width / 2);
                                const clientY = Math.round(r.top + r.height / 2);
                                const target = document.elementFromPoint(clientX, clientY) || el;
                                const activationTarget = target.closest?.('button, [role="button"], [aria-label]') || el;
                                const opts = {
                                    bubbles: true,
                                    cancelable: true,
                                    composed: true,
                                    view: window,
                                    button: 0,
                                    buttons: 1,
                                    clientX,
                                    clientY,
                                    screenX: window.screenX + clientX,
                                    screenY: window.screenY + clientY,
                                    pointerId: 1,
                                    pointerType: 'mouse',
                                    isPrimary: true
                                };
                                try {
                                    target.dispatchEvent(new PointerEvent('pointerover', opts));
                                    target.dispatchEvent(new MouseEvent('mouseover', opts));
                                    target.dispatchEvent(new PointerEvent('pointermove', opts));
                                    target.dispatchEvent(new MouseEvent('mousemove', opts));
                                    target.dispatchEvent(new PointerEvent('pointerdown', opts));
                                    target.dispatchEvent(new MouseEvent('mousedown', opts));
                                    if (typeof el.focus === 'function') el.focus();
                                    if (typeof target.focus === 'function') target.focus();
                                    if (activationTarget !== target && typeof activationTarget.focus === 'function') activationTarget.focus();
                                    target.dispatchEvent(new PointerEvent('pointerup', opts));
                                    target.dispatchEvent(new MouseEvent('mouseup', opts));
                                    
                                    // el.click()과 MouseEvent('click')이 동시에 발생하면 중복 실행될 수 있음
                                    target.dispatchEvent(new MouseEvent('click', opts));
                                    if (activationTarget !== target) activationTarget.dispatchEvent(new MouseEvent('click', opts));
                                    if (target !== el && activationTarget !== el) el.dispatchEvent(new MouseEvent('click', opts));
                                    if (typeof activationTarget.click === 'function') activationTarget.click();
                                    else if (typeof el.click === 'function') el.click();
                                } catch (e) {
                                    console.error("Click error:", e);
                                }
                            };

                            const isVisible = (el) => {
                                if (!el) return false;
                                const r = el.getBoundingClientRect();
                                return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
                            };

                            const inspectReferenceImagePicker = async () => {
                                const refs = Array.isArray(cfg.referenceAssets) ? cfg.referenceAssets : [];
                                if (!refs.length) return { ok: true, skipped: true };

                                const normalize = (value) => String(value || '')
                                    .toLowerCase()
                                    .replace(/\.[a-z0-9]+$/i, '')
                                    .replace(/\s+/g, ' ')
                                    .trim();
                                const waitFor = async (finder, timeout = 7000, interval = 250) => {
                                    const endAt = Date.now() + timeout;
                                    while (Date.now() < endAt) {
                                        const found = finder();
                                        if (found) return found;
                                        await sleep(interval);
                                    }
                                    return null;
                                };

                                const buttons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(isVisible);
                                const addBtn = buttons
                                    .map((btn, index) => {
                                        const r = btn.getBoundingClientRect();
                                        const text = `${btn.getAttribute('aria-label') || ''} ${btn.getAttribute('title') || ''} ${btn.innerText || ''} ${btn.innerHTML || ''}`.toLowerCase();
                                        const isAttach = text.includes('add_2') && text.includes('만들기') && r.top > window.innerHeight * 0.45;
                                        return { btn, index, isAttach, text, rect: r };
                                    })
                                    .filter(item => item.isAttach)
                                    .sort((a, b) => b.rect.top - a.rect.top || a.rect.left - b.rect.left)[0];

                                if (!addBtn) {
                                    const diagnostic = buttons.slice(0, 12).map((btn, index) => {
                                        const r = btn.getBoundingClientRect();
                                        const text = (btn.innerText || btn.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
                                        return `#${index} "${text}" rect=${Math.round(r.x)},${Math.round(r.y)},${Math.round(r.width)},${Math.round(r.height)}`;
                                    }).join(' | ');
                                    return { ok: false, error: '이미지 첨부 버튼(add_2)을 찾지 못했습니다.', settingsLog: [`이미지 버튼 진단: ${diagnostic}`] };
                                }

                                const r = addBtn.rect;
                                recordSetting(`이미지 첨부 버튼 선택: add_2 rect=${Math.round(r.x)},${Math.round(r.y)},${Math.round(r.width)},${Math.round(r.height)}`);
                                simulateClick(addBtn.btn);
                                await sleep(dMs);

                                const selectedNames = [];
                                for (const ref of refs) {
                                    const wanted = normalize(ref.name);
                                    const option = await waitFor(() => {
                                        const options = Array.from(document.querySelectorAll('[role="option"]')).filter(isVisible);
                                        return options.find(opt => {
                                            const imgAlt = Array.from(opt.querySelectorAll('img')).map(img => img.getAttribute('alt') || '').join(' ');
                                            const text = normalize(`${opt.innerText || ''} ${imgAlt}`);
                                            return text.includes(wanted) || wanted.includes(text);
                                        });
                                    });

                                    if (!option) {
                                        const candidates = Array.from(document.querySelectorAll('[role="option"], img'))
                                            .filter(isVisible)
                                            .map((el, index) => {
                                                const rect = el.getBoundingClientRect();
                                                const text = (el.innerText || el.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
                                                return `#${index} ${el.tagName.toLowerCase()} "${text}" rect=${Math.round(rect.x)},${Math.round(rect.y)},${Math.round(rect.width)},${Math.round(rect.height)}`;
                                            })
                                            .slice(0, 20)
                                            .join(' | ');
                                        return { ok: false, error: `참조 이미지를 찾지 못했습니다: ${ref.name}`, settingsLog: [`이미지 후보: ${candidates || '후보 없음'}`] };
                                    }

                                    const alreadySelected = option.getAttribute('aria-selected') === 'true';
                                    if (!alreadySelected) {
                                        simulateClick(option);
                                        await sleep(350);
                                    }
                                    selectedNames.push(ref.name);
                                }

                                const promptAddBtn = await waitFor(() => Array.from(document.querySelectorAll('button'))
                                    .filter(isVisible)
                                    .find(btn => (btn.innerText || '').replace(/\s+/g, '').includes('프롬프트에추가'))
                                );

                                if (!promptAddBtn) {
                                    const diagnostic = Array.from(document.querySelectorAll('button'))
                                        .filter(isVisible)
                                        .map((btn, index) => {
                                            const rect = btn.getBoundingClientRect();
                                            const text = (btn.innerText || btn.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
                                            return `#${index} "${text}" rect=${Math.round(rect.x)},${Math.round(rect.y)},${Math.round(rect.width)},${Math.round(rect.height)}`;
                                        })
                                        .slice(0, 20)
                                        .join(' | ');
                                    return { ok: false, error: '프롬프트에 추가 버튼을 찾지 못했습니다.', settingsLog: [`프롬프트 추가 버튼 진단: ${diagnostic}`] };
                                }

                                simulateClick(promptAddBtn);
                                await sleep(dMs);
                                recordSetting(`참조 이미지 프롬프트 추가 완료: ${selectedNames.join(', ')}`);
                                return { ok: true };
                            };

                            const findEditor = () => {
                                const selectors = [
                                    '[data-slate-editor="true"]',
                                    '[contenteditable="true"][role="textbox"]',
                                    '[contenteditable="true"]',
                                    'textarea[placeholder]',
                                    'textarea'
                                ];

                                for (const selector of selectors) {
                                    const candidates = Array.from(document.querySelectorAll(selector)).filter(isVisible);
                                    if (candidates.length > 0) {
                                        candidates.sort((a, b) => {
                                            const ar = a.getBoundingClientRect();
                                            const br = b.getBoundingClientRect();
                                            return (br.width * br.height) - (ar.width * ar.height);
                                        });
                                        return candidates[0];
                                    }
                                }
                                return null;
                            };

                            const getEditorText = (el) => {
                                if (!el) return "";
                                if ('value' in el) return el.value || "";
                                return el.innerText || el.textContent || "";
                            };

                            const setEditorText = async (el, value) => {
                                el.focus();
                                simulateClick(el);
                                await sleep(300);

                                if ('value' in el) {
                                    el.value = '';
                                    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
                                    await sleep(100);
                                    el.value = value;
                                    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
                                    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
                                    el.dispatchEvent(new Event('change', { bubbles: true }));
                                    el.dispatchEvent(new KeyboardEvent('keyup', { key: value.slice(-1) || ' ', bubbles: true }));
                                    return;
                                }

                                document.execCommand('selectAll', false, null);
                                document.execCommand('delete', false, null);
                                await sleep(300);
                                try {
                                    el.dispatchEvent(new ClipboardEvent('paste', {
                                        bubbles: true,
                                        cancelable: true,
                                        clipboardData: new DataTransfer()
                                    }));
                                } catch (e) {}
                                document.execCommand('insertText', false, value);
                                ['beforeinput', 'input', 'change', 'keyup'].forEach(type => {
                                    el.dispatchEvent(new InputEvent(type, { inputType: 'insertText', data: value, bubbles: true }));
                                });
                                el.dispatchEvent(new KeyboardEvent('keyup', { key: value.slice(-1) || ' ', bubbles: true }));
                            };

                            // 0. 새 프로젝트 화면 처리
                            if (isMainPage || !findEditor()) {
                                const findNewProjectBtn = () => {
                                    // 1. '새 프로젝트' 텍스트를 포함한 버튼 우선 탐색 (성능 최적화)
                                    const buttons = document.querySelectorAll('button');
                                    for (const btn of buttons) {
                                        const txt = `${btn.innerText || ''} ${btn.getAttribute('aria-label') || ''}`;
                                        if ((txt.includes('새 프로젝트') || txt.includes('New Project') || txt.includes('Create')) && isVisible(btn)) return btn;
                                    }
                                    // 2. 기타 요소 탐색
                                    return Array.from(document.querySelectorAll('div, span, a, [role="button"]')).find(el => {
                                        const txt = `${el.innerText || ''} ${el.getAttribute('aria-label') || ''}`;
                                        return (txt.includes('새 프로젝트') || txt.includes('New Project') || txt.includes('Create')) && isVisible(el);
                                    });
                                };

                                const newProjectBtn = findNewProjectBtn();

                                if (newProjectBtn) {
                                    log("새 프로젝트 버튼 감지. 클릭 시도...");
                                    simulateClick(newProjectBtn);
                                    
                                    // 클릭 직후 중복 방지를 위한 짧은 대기
                                    await sleep(50); 
                                    
                                    // 에디터가 나타날 때까지 대기 (최대 15초)
                                    let editorFound = false;
                                    for (let i = 0; i < 150; i++) {
                                        await sleep(100);
                                        if (findEditor()) {
                                            log("편집 화면 진입 확인.");
                                            editorFound = true;
                                            break;
                                        }
                                    }
                                    if (!editorFound) {
                                        // 혹시 클릭이 안됐을 수 있으니 재시도
                                        log("편집 화면 진입 실패. 재시도...");
                                        const overlay = newProjectBtn.querySelector('[data-type="button-overlay"]');
                                        if (overlay) simulateClick(overlay);
                                        else simulateClick(newProjectBtn);

                                        for (let i = 0; i < 50; i++) {
                                            await sleep(100);
                                            if (findEditor()) {
                                                editorFound = true;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (!editorFound) {
                                        return { success: false, error: "새 프로젝트 생성 후 편집 화면으로 전환되지 않았습니다." };
                                    }
                                    await sleep(300); // 안정화 대기 시간 최소화
                                } else if (isMainPage) {
                                    return { success: false, error: "메인 화면에서 '새 프로젝트' 버튼을 찾을 수 없습니다." };
                                }
                            }

                            // 1. 설정 조작 (모델/비율/수량) - 프롬프트 입력 전 수행하여 UI 안정성 확보
                            const findSettingsChip = () => {
                                const tuneButtons = Array.from(document.querySelectorAll('button')).filter(b => {
                                    const icon = b.querySelector('i.google-symbols');
                                    const txt = b.innerText || "";
                                    return isVisible(b) &&
                                        !b.disabled &&
                                        b.getAttribute('aria-disabled') !== 'true' &&
                                        (icon?.innerText.trim() === 'tune' || txt.includes('설정'));
                                });
                                const tuneBtn = tuneButtons.sort((a, b) => {
                                    const ar = a.getBoundingClientRect();
                                    const br = b.getBoundingClientRect();
                                    const aScore = ar.top * 10 + ar.left;
                                    const bScore = br.top * 10 + br.left;
                                    return bScore - aScore;
                                })[0];
                                if (tuneBtn) {
                                    const r = tuneBtn.getBoundingClientRect();
                                    log(`설정 버튼 선택: tune rect=${Math.round(r.x)},${Math.round(r.y)},${Math.round(r.width)},${Math.round(r.height)}`);
                                    return tuneBtn;
                                }

                                return Array.from(document.querySelectorAll('button[aria-haspopup="menu"]')).find(b => {
                                    const txt = b.innerText;
                                    return (txt.includes('Banana') || txt.includes('Imagen') || txt.includes(':') || /x[1-4]/.test(txt)) && b.offsetWidth > 0;
                                });
                            };

                            let settingsChip = null; // 새 FLOW 구조에서는 프롬프트 입력 후 옵션 사이드바를 연다.
                            if (settingsChip) {
                                try {
                                    log("Step 1: 설정 조작 시작");
                                    simulateClick(settingsChip);
                                    
                                    let popup = null;
                                    for (let i = 0; i < 20; i++) {
                                        await sleep(150);
                                        popup = document.querySelector('[data-radix-menu-content]') ||
                                            document.querySelector('[role="dialog"]') ||
                                            document.querySelector('[data-radix-popper-content-wrapper]') ||
                                            document.body;
                                        if (popup && popup.querySelectorAll('[role="tab"]').length > 0) break;
                                    }

                                    if (popup) {
                                        log("설정 팝업 인식됨");
                                        const settingItems = Array.from(popup.querySelectorAll('button, [role="tab"], [role="menuitem"], [role="option"]'))
                                            .filter(isVisible)
                                            .slice(0, 20)
                                            .map(el => (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim())
                                            .filter(Boolean)
                                            .join(' | ');

                                        // 1-1. 모델 변경
                                        const selectModel = async () => {
                                            const targetModelName = cfg.model.split('(')[0].trim().toLowerCase();
                                            const isTargetModel = (el) => (el.innerText || '').toLowerCase().includes(targetModelName);
                                            const findModelItem = () => Array.from(document.querySelectorAll('[role="menuitem"], button'))
                                                .filter(isVisible)
                                                .find(isTargetModel);

                                            let modelItem = findModelItem();
                                            if (modelItem) {
                                                simulateClick(modelItem);
                                                await sleep(dMs);
                                                log(`모델 선택: ${cfg.model}`);
                                                return;
                                            }

                                            const modelBtn = Array.from(document.querySelectorAll('button, [role="button"]'))
                                                .filter(isVisible)
                                                .find(el => {
                                                    const txt = (el.innerText || '').toLowerCase();
                                                    const role = el.getAttribute('role') || '';
                                                    return role !== 'tab' && (txt.includes('banana') || txt.includes('nano'));
                                                }) || popup.querySelector('button[aria-haspopup="menu"]');

                                            if (!modelBtn) {
                                                log(`모델 선택 버튼을 찾지 못함: ${cfg.model}`);
                                                return;
                                            }

                                            simulateClick(modelBtn);
                                            await sleep(dMs);

                                            modelItem = findModelItem();
                                            if (modelItem) {
                                                simulateClick(modelItem);
                                                await sleep(dMs);
                                                log(`모델 선택: ${cfg.model}`);
                                            } else {
                                                log(`모델 항목을 찾지 못함: ${cfg.model}`);
                                            }
                                        };

                                        await selectModel();

                                        // 1-2. 비율 및 수량 선택
                                        const applyTabs = async () => {
                                            const allTabs = Array.from(document.querySelectorAll('[role="tab"]')).filter(isVisible);
                                            
                                            // 비율
                                            const targetRatioTab = allTabs.find(t => t.innerText.replace(/\s/g, '').includes(cfg.ratio));
                                            if (targetRatioTab && targetRatioTab.getAttribute('data-state') !== 'active') {
                                                simulateClick(targetRatioTab);
                                                await sleep(dMs / 2);
                                            }

                                            // 수량
                                            const targetCountTab = allTabs.find(t => {
                                                const tabText = t.innerText.replace(/\s/g, '').toLowerCase();
                                                const ariaControls = t.getAttribute('aria-controls') || '';
                                                const id = t.getAttribute('id') || '';
                                                const countKey = String(cfg.count);
                                                return tabText === `x${countKey}` || tabText === `${countKey}x` ||
                                                    ariaControls.endsWith(`content-${countKey}`) || id.endsWith(`trigger-${countKey}`);
                                            });
                                            if (targetCountTab && targetCountTab.getAttribute('data-state') !== 'active') {
                                                simulateClick(targetCountTab);
                                                await sleep(dMs / 2);
                                            }
                                        };

                                        await applyTabs();
                                        
                                        // 비율 리셋 방지 최종 확인
                                        await sleep(200);
                                        const finalTabs = Array.from(document.querySelectorAll('[role="tab"]')).filter(isVisible);
                                        const finalRatioTab = finalTabs.find(t => t.innerText.replace(/\s/g, '').includes(cfg.ratio));
                                        if (finalRatioTab && finalRatioTab.getAttribute('data-state') !== 'active') {
                                            simulateClick(finalRatioTab);
                                            await sleep(dMs);
                                        }
                                        
                                        document.body.click();
                                        await sleep(dMs);
                                    }
                                } catch(e) { log("설정 조작 오류: " + e.message); }
                            }

                            const imagePicker = await inspectReferenceImagePicker();
                            if (!imagePicker.ok) {
                                return { success: false, error: imagePicker.error, settingsLog: [...settingsLog, ...(imagePicker.settingsLog || [])] };
                            }

                            // 2. 에디터 찾기 및 텍스트 주입
                            log("Step 2: 프롬프트 주입 시작");
                            let editor = findEditor();
                            if (!editor) return { success: false, error: "에디터를 찾을 수 없습니다." };

                            // 텍스트 주입 (Slate.js 호환 방식)
                            try {
                                await setEditorText(editor, text);
                                
                                // 상태 확정을 위한 미세 자극
                                if (!('value' in editor)) {
                                    document.execCommand('insertText', false, ' ');
                                    editor.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
                                    await sleep(100);
                                    document.execCommand('delete', false, null);
                                    editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', bubbles: true }));
                                }
                                await sleep(dMs);
                            } catch (e) {
                                log("주입 오류: " + e.message);
                            }

                            // 3. 생성 버튼 클릭
                            log("Step 3: 생성 버튼 클릭 및 트리거");
                            const collectButtonDiagnostics = () => {
                                const btns = Array.from(document.querySelectorAll('button, [role="button"], [aria-label]')).filter(isVisible);
                                const editorRect = editor.getBoundingClientRect();

                                return btns.map((b, index) => {
                                    const r = b.getBoundingClientRect();
                                    const h = b.innerHTML.toLowerCase();
                                    const label = (b.getAttribute('aria-label') || "").toLowerCase();
                                    const title = (b.getAttribute('title') || "").toLowerCase();
                                    const txt = (b.innerText || "").toLowerCase();
                                    const joined = `${label} ${title} ${txt} ${h}`;
                                    
                                    const isBadTarget = joined.includes('upload') || joined.includes('attach') ||
                                        joined.includes('add') || joined.includes('첨부') || joined.includes('업로드') ||
                                        joined.includes('settings') || joined.includes('설정');

                                    let score = 0;
                                    if (joined.includes('generate') || joined.includes('만들기') || joined.includes('생성')) score += 80;
                                    if (joined.includes('send') || joined.includes('submit') || joined.includes('arrow') || joined.includes('play')) score += 45;
                                    if (b.querySelector('.google-symbols, svg, mat-icon')) score += 20;

                                    const overlapsEditorY = r.top < editorRect.bottom + 120 && r.bottom > editorRect.top - 80;
                                    const nearEditorX = r.left < editorRect.right + 160 && r.right > editorRect.left - 40;
                                    if (overlapsEditorY && nearEditorX) score += 35;
                                    if (r.left >= editorRect.left && r.top >= editorRect.top - 80) score += 15;

                                    const dist = Math.sqrt(Math.pow(r.right - editorRect.right, 2) + Math.pow(r.bottom - editorRect.bottom, 2));
                                    score -= Math.min(dist / 12, 60);

                                    const disabled = Boolean(b.disabled || b.getAttribute('aria-disabled') === 'true');
                                    if (isBadTarget || disabled) score -= 100;

                                    return {
                                        index,
                                        el: b,
                                        score: Math.round(score),
                                        text: (b.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80),
                                        aria: b.getAttribute('aria-label') || "",
                                        title: b.getAttribute('title') || "",
                                        disabled,
                                        tag: b.tagName.toLowerCase(),
                                        role: b.getAttribute('role') || "",
                                        rect: {
                                            x: Math.round(r.x),
                                            y: Math.round(r.y),
                                            w: Math.round(r.width),
                                            h: Math.round(r.height)
                                        }
                                    };
                                }).sort((a, b) => b.score - a.score);
                            };

                            const formatButtonDiagnostics = (items) => {
                                return items.slice(0, 8).map(item => {
                                    const label = item.aria || item.title || item.text || "(no label)";
                                    return `#${item.index} score=${item.score} disabled=${item.disabled} ${item.tag}${item.role ? `[${item.role}]` : ""} "${label}" rect=${item.rect.x},${item.rect.y},${item.rect.w},${item.rect.h}`;
                                }).join(" | ");
                            };

                            const findGenBtn = () => {
                                const best = collectButtonDiagnostics().find(item => item.score >= 35 && !item.disabled);
                                return best ? best.el : null;
                            };

                            const findPromptSettingsBtn = () => {
                                const gen = collectButtonDiagnostics().find(item => item.score >= 35 && !item.disabled);
                                const genRect = gen?.rect;
                                const scoreByGen = (el) => {
                                    const r = el.getBoundingClientRect();
                                    if (!genRect) return { r, score: r.top * 10 + r.left };
                                    const cy = r.top + r.height / 2;
                                    const genCy = genRect.y + genRect.h / 2;
                                    const dx = Math.abs(r.right - genRect.x);
                                    const dy = Math.abs(cy - genCy);
                                    let score = 1000 - (dx * 2) - (dy * 8);
                                    if (r.right <= genRect.x + 24) score += 300;
                                    return { r, score };
                                };

                                if ((cfg.flowMode || 'normal') === 'normal') {
                                    const modelPattern = /(banana|imagen|veo|nano|flash|pro|x[1-4]|[1-4]x)/i;
                                    const modelButtons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(el => {
                                        const txt = `${el.innerText || ''} ${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''}`;
                                        const iconText = Array.from(el.querySelectorAll('i.google-symbols')).map(i => i.innerText.trim()).join(' ');
                                        const r = el.getBoundingClientRect();
                                        const nearPromptBar = !genRect || Math.abs((r.top + r.height / 2) - (genRect.y + genRect.h / 2)) < 90;
                                        return isVisible(el) &&
                                            !el.disabled &&
                                            el.getAttribute('aria-disabled') !== 'true' &&
                                            modelPattern.test(txt) &&
                                            nearPromptBar &&
                                            r.width <= 520 &&
                                            r.height <= 90 &&
                                            !iconText.includes('arrow_forward') &&
                                            !txt.includes('에이전트');
                                    });
                                    if (modelButtons.length > 0) {
                                        const picked = modelButtons
                                            .map(btn => ({ btn, ...scoreByGen(btn) }))
                                            .sort((a, b) => b.score - a.score)[0];
                                        recordSetting(`설정 버튼 선택: 일반 모드 rect=${Math.round(picked.r.x)},${Math.round(picked.r.y)},${Math.round(picked.r.width)},${Math.round(picked.r.height)}`);
                                        return picked.btn;
                                    }
                                }

                                const tuneButtons = Array.from(document.querySelectorAll('button')).filter(b => {
                                    const icon = b.querySelector('i.google-symbols');
                                    const txt = b.innerText || "";
                                    return isVisible(b) &&
                                        !b.disabled &&
                                        b.getAttribute('aria-disabled') !== 'true' &&
                                        icon?.innerText.trim() === 'tune' &&
                                        txt.includes('설정');
                                });

                                if (tuneButtons.length === 0) return null;

                                const picked = tuneButtons
                                    .map(btn => ({ btn, ...scoreByGen(btn) }))
                                    .sort((a, b) => b.score - a.score)[0];

                                recordSetting(`설정 버튼 선택: 에이전트 모드 tune rect=${Math.round(picked.r.x)},${Math.round(picked.r.y)},${Math.round(picked.r.width)},${Math.round(picked.r.height)}`);
                                return picked.btn;
                            };

                            const clickSaveSettings = async () => {
                                const saveBtn = Array.from(document.querySelectorAll('button'))
                                    .filter(isVisible)
                                    .find(btn => (btn.innerText || "").replace(/\s/g, '') === '저장');
                                if (!saveBtn) {
                                    recordSetting("설정 저장 버튼을 찾지 못함");
                                    return false;
                                }
                                const r = saveBtn.getBoundingClientRect();
                                recordSetting(`설정 저장 클릭: rect=${Math.round(r.x)},${Math.round(r.y)},${Math.round(r.width)},${Math.round(r.height)}`);
                                simulateClick(saveBtn);
                                await sleep(dMs);
                                return true;
                            };

                            const configurePromptOptions = async () => {
                                const settingsBtn = findPromptSettingsBtn();
                                if (!settingsBtn) {
                                    recordSetting("설정 버튼을 찾지 못함");
                                    return { ok: false };
                                }
                                const settingsRect = settingsBtn.getBoundingClientRect();
                                const settingsClickPoint = {
                                    x: Math.round(settingsRect.left + settingsRect.width / 2),
                                    y: Math.round(settingsRect.top + settingsRect.height / 2)
                                };

                                simulateClick(settingsBtn);
                                await sleep(dMs);

                                const hasSaveButton = () => Array.from(document.querySelectorAll('button'))
                                    .filter(isVisible)
                                    .some(btn => (btn.innerText || "").replace(/\s/g, '') === '저장');

                                const hasExplicitSaveButton = hasSaveButton();
                                if (!hasExplicitSaveButton && (cfg.flowMode || 'normal') !== 'normal') {
                                    recordSetting("옵션 사이드바가 열리지 않음. CDP 클릭 필요");
                                    return { ok: false, settingsClickPoint };
                                }
                                if (!hasExplicitSaveButton) {
                                    recordSetting("일반 모드 옵션 패널 감지: 저장 버튼 없이 즉시 적용");
                                }

                                const settingItems = Array.from(document.querySelectorAll('button, [role="tab"], [role="menuitem"], [role="option"]'))
                                    .filter(isVisible)
                                    .slice(0, 30)
                                    .map(el => (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim())
                                    .filter(Boolean)
                                    .join(' | ');

                                const allTabs = Array.from(document.querySelectorAll('[role="tab"]')).filter(isVisible);
                                const imageTab = allTabs.find(t => {
                                    const tabText = (t.innerText || '').replace(/\s/g, '').toLowerCase();
                                    const ariaControls = (t.getAttribute('aria-controls') || '').toUpperCase();
                                    const iconText = Array.from(t.querySelectorAll('i.google-symbols')).map(i => i.innerText.trim()).join(' ');
                                    return tabText === '이미지' || tabText === 'image' || ariaControls.includes('CONTENT-IMAGE') || iconText.includes('image');
                                });
                                if (imageTab && imageTab.getAttribute('data-state') !== 'active') {
                                    simulateClick(imageTab);
                                    await sleep(dMs / 2);
                                    recordSetting('이미지 탭 선택');
                                }

                                const targetRatioTab = allTabs.find(t => t.innerText.replace(/\s/g, '').includes(cfg.ratio));
                                if (targetRatioTab && targetRatioTab.getAttribute('data-state') !== 'active') {
                                    simulateClick(targetRatioTab);
                                    await sleep(dMs / 2);
                                    recordSetting(`비율 선택: ${cfg.ratio}`);
                                }

                                const targetCountTab = allTabs.find(t => {
                                    const tabText = t.innerText.replace(/\s/g, '').toLowerCase();
                                    const ariaControls = t.getAttribute('aria-controls') || '';
                                    const id = t.getAttribute('id') || '';
                                    const countKey = String(cfg.count);
                                    return tabText === `x${countKey}` || tabText === `${countKey}x` ||
                                        ariaControls.endsWith(`content-${countKey}`) || id.endsWith(`trigger-${countKey}`);
                                });
                                if (targetCountTab && targetCountTab.getAttribute('data-state') !== 'active') {
                                    simulateClick(targetCountTab);
                                    await sleep(dMs / 2);
                                    recordSetting(`수량 선택: x${cfg.count}`);
                                }

                                const normalizeModelText = (value) => String(value || '')
                                    .replace(/🍌/g, '')
                                    .replace(/arrow_drop_down/g, '')
                                    .replace(/crop_\S+/g, '')
                                    .replace(/(^|\s)([1-4]x|x[1-4])($|\s)/g, ' ')
                                    .replace(/\s+/g, ' ')
                                    .trim()
                                    .toLowerCase();
                                const targetModelName = normalizeModelText(cfg.model.split('(')[0]);
                                const isTargetModel = (el) => {
                                    const normalized = normalizeModelText(el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '');
                                    if (targetModelName === 'nano banana 2') return normalized === 'nano banana 2';
                                    return normalized === targetModelName || normalized.includes(targetModelName);
                                };
                                const visibleModelButtons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(isVisible);
                                const currentModelButton = visibleModelButtons
                                    .map(el => {
                                        const txt = (el.innerText || '').toLowerCase();
                                        const role = el.getAttribute('role') || '';
                                        const ariaHasPopup = el.getAttribute('aria-haspopup') || '';
                                        const iconText = Array.from(el.querySelectorAll('i.google-symbols')).map(i => i.innerText.trim()).join(' ');
                                        const r = el.getBoundingClientRect();
                                        let score = 0;
                                        if (role === 'tab') score -= 300;
                                        if (txt.includes('banana') || txt.includes('nano')) score += 120;
                                        if (ariaHasPopup === 'menu') score += 260;
                                        if (iconText.includes('arrow_drop_down')) score += 260;
                                        if (r.width < 80 || r.height < 24) score -= 80;
                                        return { el, score, text: normalizeModelText(el.innerText || '') };
                                    })
                                    .filter(item => item.score > 0)
                                    .sort((a, b) => b.score - a.score)[0];

                                if (currentModelButton?.text && currentModelButton.text === targetModelName) {
                                    recordSetting(`모델 유지: ${cfg.model}`);
                                } else {
                                    let modelItem = Array.from(document.querySelectorAll('[role="menuitem"], [role="option"], button'))
                                        .filter(isVisible)
                                        .find(isTargetModel);

                                    if (!modelItem && currentModelButton?.el) {
                                        simulateClick(currentModelButton.el);
                                        await sleep(dMs);
                                        modelItem = Array.from(document.querySelectorAll('[role="menuitem"], [role="option"], button'))
                                            .filter(isVisible)
                                            .find(isTargetModel);
                                    }

                                    if (modelItem) {
                                        simulateClick(modelItem);
                                        await sleep(dMs);
                                        recordSetting(`모델 선택: ${cfg.model}`);
                                    } else {
                                        recordSetting(`모델 항목을 찾지 못함: ${cfg.model}`);
                                    }
                                }

                                if (!hasExplicitSaveButton) {
                                    simulateClick(settingsBtn);
                                    await sleep(dMs);
                                    const stillOpen = Array.from(document.querySelectorAll('[role="menu"], [role="dialog"], [data-radix-menu-content], [data-radix-popper-content-wrapper]'))
                                        .some(isVisible);
                                    if (stillOpen) {
                                        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
                                        document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
                                        await sleep(dMs / 2);
                                    }
                                    recordSetting("일반 모드 옵션 패널 닫기 완료");
                                    return { ok: true, settingsClickPoint };
                                }

                                const saved = await clickSaveSettings();
                                return { ok: saved, settingsClickPoint };
                            };

                            const failWithDiagnostics = (error) => {
                                const best = collectButtonDiagnostics().find(item => item.score >= 35 && !item.disabled);
                                return {
                                    success: false,
                                    error,
                                    settingsLog,
                                    diagnostics: formatButtonDiagnostics(collectButtonDiagnostics()),
                                    clickPoint: best ? {
                                        x: Math.round(best.rect.x + best.rect.w / 2),
                                        y: Math.round(best.rect.y + best.rect.h / 2)
                                    } : null
                                };
                            };

                            const fireEnterShortcut = (target, opts = {}) => {
                                const eventOpts = {
                                    key: 'Enter',
                                    code: 'Enter',
                                    keyCode: 13,
                                    which: 13,
                                    bubbles: true,
                                    cancelable: true,
                                    ...opts
                                };
                                target.dispatchEvent(new KeyboardEvent('keydown', eventOpts));
                                target.dispatchEvent(new KeyboardEvent('keyup', eventOpts));
                            };

                            const isGenerationStarted = () => {
                                const buttons = Array.from(document.querySelectorAll('button, [role="button"]')).filter(isVisible);
                                const hasStopBtn = buttons.some(b => {
                                    const label = (b.getAttribute('aria-label') || "").toLowerCase();
                                    const title = (b.getAttribute('title') || "").toLowerCase();
                                    const t = (b.innerText || "").toLowerCase();
                                    const joined = `${label} ${title} ${t}`;
                                    return joined.includes('stop') || joined.includes('중지');
                                });

                                const bodyText = document.body.innerText.toLowerCase();
                                const hasProgressText = bodyText.includes('generating') || bodyText.includes('creating') ||
                                    bodyText.includes('생성 중') || bodyText.includes('만드는 중') || bodyText.includes('처리 중');

                                return hasStopBtn || hasProgressText;
                            };

                            // 클릭 전 프롬프트 주입 여부 최종 확인
                            const textLenBefore = getEditorText(editor).trim().length;
                            if (textLenBefore < 1) {
                                log("❌ 프롬프트 주입 확인 실패. 재시도합니다.");
                                return failWithDiagnostics("Prompt not injected");
                            }

                            if (cfg.settingsApplied || cfg.skipOptions) {
                                recordSetting(cfg.skipOptions ? "다중 프롬프트 후속 작업: 옵션 단계 스킵" : "옵션 설정은 이미 저장됨. 옵션 단계 스킵");
                            } else {
                                const optionResult = await configurePromptOptions();
                                if (!optionResult?.ok) {
                                    return {
                                        success: false,
                                        error: "옵션 사이드바를 열지 못했습니다.",
                                        settingsLog,
                                        settingsClickPoint: optionResult?.settingsClickPoint || null,
                                        diagnostics: formatButtonDiagnostics(collectButtonDiagnostics())
                                    };
                                }
                            }

                            let genBtn = findGenBtn();
                            if (genBtn) {
                                log("생성 버튼 클릭 및 단축키 실행");
                                simulateClick(genBtn);
                                
                                // 단축키 백업 트리거
                                editor.focus();
                                fireEnterShortcut(editor, { ctrlKey: true });
                                fireEnterShortcut(document, { ctrlKey: true });
                                fireEnterShortcut(editor, { metaKey: true });
                                
                                // 성공 판별 (최대 15초)
                                let isStarted = false;
                                await sleep(500); // UI 반응 대기

                                for (let j = 0; j < 75; j++) {
                                    await sleep(200);
                                    
                                    const startedByUi = isGenerationStarted();
                                    if (startedByUi) {
                                        log(`✅ 생성 시작 확인됨 (StartedUi: ${startedByUi})`);
                                        isStarted = true;
                                        break;
                                    }
                                }
                                return isStarted ? { success: true, settingsLog } : failWithDiagnostics("생성 버튼 클릭 후 시작 상태를 감지하지 못했습니다.");
                            } else {
                                log("⚠️ 버튼 탐색 실패, 엔터키 단독 시도");
                                editor.focus();
                                await sleep(500);
                                fireEnterShortcut(editor, { ctrlKey: true });
                                fireEnterShortcut(document, { ctrlKey: true });
                                fireEnterShortcut(editor, { metaKey: true });
                                
                                let isStartedFallback = false;
                                for (let j = 0; j < 50; j++) {
                                    await sleep(200);
                                    if (isGenerationStarted() || getEditorText(editor).trim().length < (textLenBefore * 0.2)) {
                                        isStartedFallback = true;
                                        break;
                                    }
                                }
                                return isStartedFallback ? { success: true, settingsLog } : failWithDiagnostics("생성 버튼을 찾지 못했고 단축키도 실패했습니다.");
                            }
                        },
                        args: [currentPrompt, {
                            ...config,
                            referenceAssets: sceneReferenceAssets,
                            settingsApplied,
                            skipOptions: prompts.length > 1 && currentPromptIndex > 0
                        }]
                    });

                    const res = result[0]?.result;
                    if (res && res.success) {
                        if (res.settingsLog?.length) {
                            res.settingsLog.forEach(msg => debugLog(`⚙️ ${msg}`));
                        }
                        success = true;
                        break;
                    } else {
                        const errMsg = res?.error || t('errEditorBusy');
                        if (res?.settingsLog?.length) {
                            res.settingsLog.forEach(msg => debugLog(`⚙️ ${msg}`));
                        }
                        if (res?.settingsClickPoint && !settingsFallbackUsed) {
                            settingsFallbackUsed = true;
                            debugLog(`🖱 옵션 버튼 CDP 클릭 시도 (${res.settingsClickPoint.x}, ${res.settingsClickPoint.y})`);
                            const settingsClickRes = await debuggerClick(res.settingsClickPoint);
                            let settingsSaved = false;
                            if (settingsClickRes.success) {
                                await wait(1200);
                                const settingsRes = await configureOpenSettingsSidebar();
                                settingsRes.log?.forEach(msg => debugLog(`⚙️ ${msg}`));
                                if (settingsRes.success) {
                                    settingsSaved = true;
                                    settingsApplied = true;
                                    addLog("✅ 옵션 저장 완료. 생성 버튼을 기다립니다.");
                                    await wait(5000);
                                    const genPoint = await findGenerationClickPoint();
                                    debugLog(`🔎 저장 후 생성 버튼 진단: ${genPoint.diagnostic}`);
                                    let clickPoint = genPoint.point;
                                    if (!clickPoint) {
                                        const anyGenPoint = await findAnyVisibleGenerateClickPoint();
                                        debugLog(`🔎 보이는 생성 버튼 fallback 진단: ${anyGenPoint.diagnostic}`);
                                        clickPoint = anyGenPoint.point;
                                    }
                                    if (clickPoint) {
                                        debugLog(`🖱 저장 후 생성 버튼 CDP 클릭 (${clickPoint.x}, ${clickPoint.y})`);
                                        const genClickRes = await debuggerClick(clickPoint);
                                        if (genClickRes.success && await waitForGenerationStart()) {
                                            addLog("✅ 저장 후 생성 시작 확인됨");
                                            success = true;
                                            break;
                                        }
                                        debugLog(`⚠️ 저장 후 생성 클릭 실패 또는 시작 미감지. (${genClickRes.error || 'no start signal'})`);
                                    }
                                }
                            }
                            if (!settingsSaved) {
                                debugLog(`⚠️ 옵션 버튼 CDP 클릭 또는 저장 실패. (${settingsClickRes.error || 'settings not saved'})`);
                            }
                        }
                        if (res?.clickPoint) {
                            debugLog(`🖱 CDP 클릭 fallback 시도 (${res.clickPoint.x}, ${res.clickPoint.y})`);
                            const clickRes = await debuggerClick(res.clickPoint);
                            if (clickRes.success && await waitForGenerationStart()) {
                                addLog("✅ 생성 시작 확인됨");
                                success = true;
                                break;
                            }
                            debugLog(`⚠️ CDP 클릭 실패 또는 시작 미감지. (${clickRes.error || 'no start signal'})`);
                        }

                        addLog(t('logGenStartFail', { error: errMsg }));
                        if (res?.diagnostics) {
                            debugLog(`🔎 버튼 진단: ${res.diagnostics}`);
                        }
                    }
                }

                if (!success && isRunning) {
                    addLog(t('logRetryFailed', { count: config.retryCount }));
                } else if (success) {
                    addLog(t('logWaitGen', { time: config.waitTime }));
                    for (let s = 0; s < config.waitTime; s++) {
                        if (isPaused || !isRunning) break;
                        await wait(1000);
                    }
                    if (!isRunning) break;

                    // [임시 중단] 자동 다운로드 기능은 배제하고 생성 확인만 진행
                    /*
                    if (config.autoDl && !isPaused && isRunning) {
                        addLog("💾 이미지 생성 완료 확인 및 개별 다운로드 시작...");
                        // ... 다운로드 관련 코드 생략 ...
                    }
                    */

                    addLog(t('logDone', { current: currentPromptIndex + 1, total: prompts.length }));
                }
                
                if (!isRunning) {
                    addLog(t('logStopped'));
                    break;
                }

                if (isPaused) {
                    addLog(t('logPaused'));
                    startBtn.disabled = false;
                    startBtn.innerText = t('resumeBtn');
                    break;
                }
            }

            if (currentPromptIndex >= prompts.length || !isRunning) {
                if (currentPromptIndex >= prompts.length) {
                    addLog(t('logAllDone'));
                }
                isRunning = false;
                isPaused = false;
                startBtn.disabled = false;
                startBtn.innerText = t('startBtn');
                pauseBtn.disabled = true;
                pauseBtn.innerText = t('pauseBtn');
                stopBtn.disabled = true;
                document.getElementById('statusArea').style.display = 'none';
            }
        } catch (err) {
            addLog(t('logFatalError', { error: err.message }));
            isRunning = false;
            isPaused = false;
            startBtn.disabled = false;
            startBtn.innerText = t('startBtn');
            pauseBtn.disabled = true;
            pauseBtn.innerText = t('pauseBtn');
            stopBtn.disabled = true;
            document.getElementById('statusArea').style.display = 'none';
        }
    };
};

init();
})();
