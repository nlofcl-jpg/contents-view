// FLOW AUTOMI authentication configuration
// Supabase Dashboard > Project Settings > API 값을 입력하세요.
self.FLOW_AUTH_CONFIG = {
  SUPABASE_URL: "https://fgkwosbfnjgrfgyzrdap.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_tfk3Vkc96386Lf9G-xfUzw_0zjR3riO"
};
