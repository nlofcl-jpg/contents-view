-- FLOW AUTOMI Supabase authorization setup
-- Supabase Dashboard > SQL Editor에서 실행하세요.

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'user' check (role in ('admin', 'user')),
  plan text not null default 'free' check (plan in ('admin', 'free', 'basic', 'pro')),
  status text not null default 'active' check (status in ('pending', 'active', 'blocked', 'expired')),
  daily_limit integer not null default 100,
  monthly_limit integer not null default 0,
  used_today integer not null default 0,
  used_month integer not null default 0,
  allow_multi_prompt boolean not null default false,
  allow_reference_image boolean not null default false,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
on public.profiles
for select
to authenticated
using (auth.uid() = user_id);

-- 새 가입자가 생기면 active/free/일 100회 프로필을 자동 생성합니다.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (user_id, email, status, daily_limit, monthly_limit)
  values (new.id, new.email, 'active', 100, 0)
  on conflict (user_id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- 기존에 가입된 사용자가 있다면 프로필을 한 번에 생성합니다.
insert into public.profiles (user_id, email, status, daily_limit, monthly_limit)
select id, email, 'active', 100, 0 from auth.users
on conflict (user_id) do update set email = excluded.email;

-- 관리자 지정 예시:
-- update public.profiles
-- set role = 'admin', plan = 'admin', status = 'active', daily_limit = 999999, monthly_limit = 999999,
--     allow_multi_prompt = true, allow_reference_image = true
-- where email = 'YOUR_EMAIL@gmail.com';

-- 일반 사용자 기본 일 100회 적용 예시:
-- update public.profiles
-- set status = 'active', plan = 'free', daily_limit = 100, monthly_limit = 0,
--     allow_multi_prompt = false, allow_reference_image = false
-- where role <> 'admin';


-- 사용량 날짜/월 기준 리셋을 위한 컬럼입니다.
alter table public.profiles add column if not exists usage_day date not null default current_date;
alter table public.profiles add column if not exists usage_month_key text not null default to_char(current_date, 'YYYY-MM');

-- 자동화 실행 전 권한을 확인하고 사용량을 차감합니다.
create or replace function public.consume_flow_usage(p_units integer default 1)
returns public.profiles
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile public.profiles;
  v_units integer := greatest(coalesce(p_units, 1), 1);
  v_today date := current_date;
  v_month text := to_char(current_date, 'YYYY-MM');
begin
  select * into v_profile
  from public.profiles
  where user_id = auth.uid()
  for update;

  if not found then
    raise exception 'PROFILE_NOT_FOUND';
  end if;

  if v_profile.status <> 'active' then
    raise exception 'ACCOUNT_NOT_ACTIVE:%', v_profile.status;
  end if;

  if v_profile.expires_at is not null and v_profile.expires_at < now() then
    raise exception 'ACCOUNT_EXPIRED';
  end if;

  if v_profile.usage_day <> v_today then
    v_profile.used_today := 0;
    v_profile.usage_day := v_today;
  end if;

  if v_profile.usage_month_key <> v_month then
    v_profile.used_month := 0;
    v_profile.usage_month_key := v_month;
  end if;

  if v_profile.role <> 'admin' then
    if v_profile.daily_limit <= 0 or v_profile.used_today + v_units > v_profile.daily_limit then
      raise exception 'DAILY_LIMIT_EXCEEDED';
    end if;

    if v_profile.monthly_limit > 0 and v_profile.used_month + v_units > v_profile.monthly_limit then
      raise exception 'MONTHLY_LIMIT_EXCEEDED';
    end if;
  end if;

  update public.profiles
  set used_today = v_profile.used_today + v_units,
      used_month = v_profile.used_month + v_units,
      usage_day = v_today,
      usage_month_key = v_month,
      updated_at = now()
  where user_id = auth.uid()
  returning * into v_profile;

  return v_profile;
end;
$$;

grant execute on function public.consume_flow_usage(integer) to authenticated;

-- 공지사항 테이블입니다. 확장프로그램은 활성화된 최신 공지 1개를 12시간마다 확인합니다.
create table if not exists public.announcements (
  id bigserial primary key,
  title text not null,
  message text not null,
  is_active boolean not null default true,
  starts_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.announcements enable row level security;

drop policy if exists "announcements_select_active" on public.announcements;
create policy "announcements_select_active"
on public.announcements
for select
to anon, authenticated
using (is_active = true and starts_at <= now());

grant select on public.announcements to anon, authenticated;

drop policy if exists "announcements_admin_select" on public.announcements;
create policy "announcements_admin_select"
on public.announcements
for select
to authenticated
using (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

drop policy if exists "announcements_admin_insert" on public.announcements;
create policy "announcements_admin_insert"
on public.announcements
for insert
to authenticated
with check (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

drop policy if exists "announcements_admin_update" on public.announcements;
create policy "announcements_admin_update"
on public.announcements
for update
to authenticated
using (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
))
with check (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

drop policy if exists "announcements_admin_delete" on public.announcements;
create policy "announcements_admin_delete"
on public.announcements
for delete
to authenticated
using (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

grant insert, update, delete on public.announcements to authenticated;
grant usage, select on sequence public.announcements_id_seq to authenticated;

-- 공지 등록 예시:
-- insert into public.announcements (title, message)
-- values ('공지 제목', '공지 내용입니다.');

-- 앱 내부 고정 콘텐츠 테이블입니다. 정보 페이지 등 관리형 문구를 저장합니다.
create table if not exists public.app_contents (
  content_key text primary key,
  title text not null,
  body text not null,
  updated_at timestamptz not null default now()
);

alter table public.app_contents enable row level security;

drop policy if exists "app_contents_select_all" on public.app_contents;
create policy "app_contents_select_all"
on public.app_contents
for select
to anon, authenticated
using (true);

drop policy if exists "app_contents_admin_insert" on public.app_contents;
create policy "app_contents_admin_insert"
on public.app_contents
for insert
to authenticated
with check (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

drop policy if exists "app_contents_admin_update" on public.app_contents;
create policy "app_contents_admin_update"
on public.app_contents
for update
to authenticated
using (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
))
with check (exists (
  select 1 from public.profiles
  where user_id = auth.uid() and role = 'admin' and status = 'active'
));

grant select on public.app_contents to anon, authenticated;
grant insert, update on public.app_contents to authenticated;

insert into public.app_contents (content_key, title, body)
values ('info', '준비 중인 페이지입니다', '사이트 소개 및 안내 정보가
이곳에 표시될 예정입니다.')
on conflict (content_key) do nothing;

