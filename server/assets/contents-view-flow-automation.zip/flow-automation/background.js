// FLOW AUTOMI - Background Service Worker
importScripts('auth-config.js');
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);


const getAuthConfig = () => self.FLOW_AUTH_CONFIG || {};
const isAuthConfigured = () => {
  const cfg = getAuthConfig();
  return Boolean(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY);
};
const getSupabaseUrl = (path) => `${getAuthConfig().SUPABASE_URL.replace(/\/$/, '')}${path}`;
const parseAuthRedirect = (url) => {
  const parsed = new URL(url);
  const hash = new URLSearchParams((parsed.hash || '').replace(/^#/, ''));
  const query = new URLSearchParams(parsed.search || '');
  const params = hash.get('access_token') ? hash : query;
  return {
    access_token: params.get('access_token'),
    id_token: params.get('id_token'),
    refresh_token: params.get('refresh_token'),
    provider_token: params.get('provider_token'),
    expires_in: Number(params.get('expires_in') || 3600),
    token_type: params.get('token_type') || 'bearer',
    keys: Array.from(params.keys())
  };
};
const decodeJwtPayload = (token) => {
  try {
    const payload = token.split('.')[1];
    if (!payload) return null;
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
    const json = atob(normalized.padEnd(normalized.length + (4 - normalized.length % 4) % 4, '='));
    return JSON.parse(json);
  } catch (e) {
    return null;
  }
};
const readUserFromToken = (token) => {
  const payload = decodeJwtPayload(token);
  if (!payload) return null;
  const metadata = payload.user_metadata || payload.app_metadata || {};
  const email = payload.email || metadata.email || '';
  const id = payload.sub || payload.user_id || email;
  if (!id && !email) return null;
  return { id, email, user_metadata: metadata };
};
const fetchSupabaseUser = async (token) => {
  const user = readUserFromToken(token.id_token) || readUserFromToken(token.access_token);
  if (!user) {
    throw new Error(`로그인 토큰에서 사용자 정보를 읽지 못했습니다. 콜백 키: ${(token.keys || []).join(', ') || '없음'}`);
  }
  return user;
};
const fetchUserProfile = async (session) => {
  const cfg = getAuthConfig();
  if (!session?.access_token) {
    throw new Error('로그인 세션이 없습니다.');
  }
  const headers = {
    apikey: cfg.SUPABASE_ANON_KEY,
    Authorization: `Bearer ${session.access_token}`,
    Accept: 'application/json'
  };
  const queries = [];
  if (session.user?.id) {
    queries.push(`/rest/v1/profiles?select=*&user_id=eq.${encodeURIComponent(session.user.id)}&limit=1`);
  }
  if (session.user?.email) {
    queries.push(`/rest/v1/profiles?select=*&email=eq.${encodeURIComponent(session.user.email)}&limit=1`);
  }
  let lastError = null;
  for (const query of queries) {
    const res = await fetch(getSupabaseUrl(query), { headers });
    if (!res.ok) {
      if (res.status === 401) {
        await clearStoredAuth();
        throw new Error('로그인이 만료되었습니다. 다시 로그인해주세요.');
      }
      lastError = new Error(`권한 정보 조회 실패 (${res.status})`);
      continue;
    }
    const rows = await res.json();
    if (rows[0]) return rows[0];
  }
  if (lastError) throw lastError;
  return null;
};
const consumeFlowUsage = async (session, units) => {
  const cfg = getAuthConfig();
  if (!session?.access_token) throw new Error('로그인 세션이 없습니다.');
  const res = await fetch(getSupabaseUrl('/rest/v1/rpc/consume_flow_usage'), {
    method: 'POST',
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json'
    },
    body: JSON.stringify({ p_units: Math.max(1, Number(units) || 1) })
  });
  const payloadText = await res.text();
  let payload = null;
  try { payload = payloadText ? JSON.parse(payloadText) : null; } catch (e) { payload = payloadText; }
  if (!res.ok) {
    if (res.status === 401) {
      await clearStoredAuth();
      throw new Error('로그인이 만료되었습니다. 다시 로그인해주세요.');
    }
    const message = payload?.message || payload?.error || payloadText || `사용량 차감 실패 (${res.status})`;
    throw new Error(message);
  }
  return Array.isArray(payload) ? payload[0] : payload;
};
const openAuthPopup = (authUrl, redirectUrl) => new Promise((resolve, reject) => {
  let popupWindowId = null;
  let popupTabId = null;
  let settled = false;

  const cleanup = () => {
    chrome.tabs.onUpdated.removeListener(onUpdated);
    chrome.tabs.onRemoved.removeListener(onRemoved);
  };
  const finish = (callback, value) => {
    if (settled) return;
    settled = true;
    cleanup();
    if (popupWindowId !== null) {
      chrome.windows.remove(popupWindowId, () => void chrome.runtime.lastError);
    }
    callback(value);
  };
  const onUpdated = (tabId, changeInfo, tab) => {
    if (tabId !== popupTabId) return;
    const nextUrl = changeInfo.url || tab?.url || '';
    if (nextUrl.startsWith(redirectUrl)) {
      finish(resolve, nextUrl);
    }
  };
  const onRemoved = (tabId) => {
    if (tabId === popupTabId) {
      finish(reject, new Error('로그인 창이 닫혔습니다.'));
    }
  };

  chrome.windows.create({
    url: authUrl,
    type: 'popup',
    width: 480,
    height: 720,
    focused: true
  }, (win) => {
    if (chrome.runtime.lastError) {
      reject(new Error(chrome.runtime.lastError.message));
      return;
    }
    popupWindowId = win?.id ?? null;
    popupTabId = win?.tabs?.[0]?.id ?? null;
    if (!popupTabId) {
      reject(new Error('로그인 팝업 탭을 열지 못했습니다.'));
      return;
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
});
const getStoredAuth = () => new Promise(resolve => {
  chrome.storage.local.get('flowAuthSession', data => resolve(data.flowAuthSession || null));
});
const setStoredAuth = (session) => new Promise(resolve => {
  chrome.storage.local.set({ flowAuthSession: session }, resolve);
});
const clearStoredAuth = () => new Promise(resolve => {
  chrome.storage.local.remove('flowAuthSession', resolve);
});
const refreshAuthSession = async (session) => {
  const cfg = getAuthConfig();
  if (!session?.refresh_token) {
    throw new Error('로그인이 만료되었습니다. 다시 로그인해주세요.');
  }
  const res = await fetch(getSupabaseUrl('/auth/v1/token?grant_type=refresh_token'), {
    method: 'POST',
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
      Accept: 'application/json'
    },
    body: JSON.stringify({ refresh_token: session.refresh_token })
  });
  const payload = await res.json().catch(() => null);
  if (!res.ok || !payload?.access_token) {
    throw new Error('로그인이 만료되었습니다. 다시 로그인해주세요.');
  }
  const user = payload.user || await fetchSupabaseUser({
    access_token: payload.access_token,
    id_token: payload.id_token,
    keys: ['refresh_token']
  });
  const nextSession = {
    access_token: payload.access_token,
    refresh_token: payload.refresh_token || session.refresh_token,
    expires_at: Date.now() + Number(payload.expires_in || 3600) * 1000,
    user: {
      id: user.id,
      email: user.email,
      name: user.user_metadata?.full_name || user.user_metadata?.name || user.email || session.user?.name || '사용자'
    }
  };
  await setStoredAuth(nextSession);
  return nextSession;
};
const getValidStoredAuth = async () => {
  const session = await getStoredAuth();
  if (!session?.access_token) return null;
  const expiresAt = Number(session.expires_at || 0);
  if (expiresAt && expiresAt - Date.now() > 60000) return session;
  try {
    return await refreshAuthSession(session);
  } catch (error) {
    await clearStoredAuth();
    throw error;
  }
};

const ANNOUNCEMENT_ALARM = 'flow_check_announcements';
const ANNOUNCEMENT_CACHE_KEY = 'flowAnnouncementCache';
const ANNOUNCEMENT_INTERVAL_MINUTES = 12 * 60;

const getStoredAnnouncement = () => new Promise(resolve => {
  chrome.storage.local.get(ANNOUNCEMENT_CACHE_KEY, data => resolve(data[ANNOUNCEMENT_CACHE_KEY] || null));
});
const setStoredAnnouncement = (announcement) => new Promise(resolve => {
  chrome.storage.local.set({
    [ANNOUNCEMENT_CACHE_KEY]: {
      announcement,
      checkedAt: Date.now()
    }
  }, resolve);
});
const fetchLatestAnnouncement = async () => {
  if (!isAuthConfigured()) return null;
  const cfg = getAuthConfig();
  const url = getSupabaseUrl('/rest/v1/announcements?select=id,title,message,created_at,starts_at&is_active=eq.true&starts_at=lte.now()&order=starts_at.desc,created_at.desc&limit=1');
  const res = await fetch(url, {
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      Accept: 'application/json'
    }
  });
  if (!res.ok) throw new Error(`공지 조회 실패 (${res.status})`);
  const rows = await res.json();
  return rows[0] || null;
};
const refreshAnnouncementCache = async () => {
  const announcement = await fetchLatestAnnouncement();
  await setStoredAnnouncement(announcement);
  return announcement;
};

const requireAdminSession = async () => {
  const session = await getValidStoredAuth();
  if (!session?.access_token) throw new Error('로그인이 필요합니다.');
  const profile = await fetchUserProfile(session);
  if (profile?.role !== 'admin' || profile?.status !== 'active') {
    throw new Error('관리자 권한이 필요합니다.');
  }
  return { session, profile };
};
const adminAnnouncementRequest = async (path, options = {}) => {
  const cfg = getAuthConfig();
  const { session } = await requireAdminSession();
  const res = await fetch(getSupabaseUrl(path), {
    ...options,
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Prefer: 'return=representation',
      ...(options.headers || {})
    }
  });
  const payloadText = await res.text();
  let payload = null;
  try { payload = payloadText ? JSON.parse(payloadText) : null; } catch (e) { payload = payloadText; }
  if (!res.ok) {
    const message = payload?.message || payload?.error || payloadText || `공지 관리 실패 (${res.status})`;
    throw new Error(message);
  }
  await refreshAnnouncementCache().catch(() => null);
  return payload;
};

const fetchAppContent = async (key) => {
  const cfg = getAuthConfig();
  const res = await fetch(getSupabaseUrl(`/rest/v1/app_contents?select=content_key,title,body,updated_at&content_key=eq.${encodeURIComponent(key)}&limit=1`), {
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      Accept: 'application/json'
    }
  });
  if (!res.ok) throw new Error(`정보 조회 실패 (${res.status})`);
  const rows = await res.json();
  return rows[0] || null;
};
const saveAppContent = async (key, title, body) => {
  const cfg = getAuthConfig();
  const { session } = await requireAdminSession();
  const res = await fetch(getSupabaseUrl('/rest/v1/app_contents?on_conflict=content_key'), {
    method: 'POST',
    headers: {
      apikey: cfg.SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Prefer: 'resolution=merge-duplicates,return=representation'
    },
    body: JSON.stringify({ content_key: key, title, body, updated_at: new Date().toISOString() })
  });
  const payloadText = await res.text();
  let payload = null;
  try { payload = payloadText ? JSON.parse(payloadText) : null; } catch (e) { payload = payloadText; }
  if (!res.ok) {
    const message = payload?.message || payload?.error || payloadText || `정보 저장 실패 (${res.status})`;
    throw new Error(message);
  }
  return Array.isArray(payload) ? payload[0] : payload;
};
const scheduleAnnouncementAlarm = () => {
  if (!chrome.alarms) return;
  chrome.alarms.create(ANNOUNCEMENT_ALARM, {
    delayInMinutes: ANNOUNCEMENT_INTERVAL_MINUTES,
    periodInMinutes: ANNOUNCEMENT_INTERVAL_MINUTES
  });
};

chrome.runtime.onInstalled.addListener(scheduleAnnouncementAlarm);
chrome.runtime.onStartup.addListener(scheduleAnnouncementAlarm);
scheduleAnnouncementAlarm();

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== ANNOUNCEMENT_ALARM) return;
    refreshAnnouncementCache().catch(console.warn);
  });
}

const isFlowUrl = (url) => {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.hostname === 'labs.google' &&
      parsed.pathname.includes('/fx/') &&
      parsed.pathname.includes('/tools/flow');
  } catch (e) {
    return url.includes('labs.google') && url.includes('/tools/flow');
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'ANNOUNCEMENT_GET') {
    (async () => {
      const cached = await getStoredAnnouncement();
      const maxAgeMs = ANNOUNCEMENT_INTERVAL_MINUTES * 60 * 1000;
      const isFresh = cached && Date.now() - Number(cached.checkedAt || 0) < maxAgeMs;
      if (!msg.force && isFresh) {
        sendResponse({ success: true, announcement: cached.announcement || null, cached: true });
        return;
      }
      try {
        const announcement = await refreshAnnouncementCache();
        sendResponse({ success: true, announcement, cached: false });
      } catch (error) {
        sendResponse({ success: Boolean(cached), announcement: cached?.announcement || null, cached: true, error: error.message });
      }
    })();
    return true;
  }

  if (msg.type === 'APP_CONTENT_GET') {
    (async () => {
      const content = await fetchAppContent(msg.key || 'info');
      sendResponse({ success: true, content });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'APP_CONTENT_SAVE') {
    (async () => {
      const title = String(msg.title || '').trim();
      const body = String(msg.body || '').trim();
      if (!title || !body) throw new Error('제목과 내용을 입력하세요.');
      const content = await saveAppContent(msg.key || 'info', title, body);
      sendResponse({ success: true, content });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'ANNOUNCEMENT_ADMIN_LIST') {
    (async () => {
      await requireAdminSession();
      const cfg = getAuthConfig();
      const session = await getValidStoredAuth();
      const res = await fetch(getSupabaseUrl('/rest/v1/announcements?select=id,title,message,is_active,starts_at,created_at&order=created_at.desc&limit=5'), {
        headers: {
          apikey: cfg.SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          Accept: 'application/json'
        }
      });
      if (!res.ok) throw new Error(`공지 목록 조회 실패 (${res.status})`);
      sendResponse({ success: true, announcements: await res.json() });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'ANNOUNCEMENT_ADMIN_SAVE') {
    (async () => {
      const id = msg.id ? Number(msg.id) : null;
      const body = JSON.stringify({
        title: String(msg.title || '').trim(),
        message: String(msg.message || '').trim(),
        is_active: true
      });
      if (!JSON.parse(body).title || !JSON.parse(body).message) throw new Error('공지 제목과 내용을 입력하세요.');
      const payload = id
        ? await adminAnnouncementRequest(`/rest/v1/announcements?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', body })
        : await adminAnnouncementRequest('/rest/v1/announcements', { method: 'POST', body });
      sendResponse({ success: true, announcement: Array.isArray(payload) ? payload[0] : payload });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'ANNOUNCEMENT_ADMIN_HIDE') {
    (async () => {
      const id = Number(msg.id);
      if (!id) throw new Error('공지 ID가 없습니다.');
      await adminAnnouncementRequest(`/rest/v1/announcements?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH',
        body: JSON.stringify({ is_active: false })
      });
      sendResponse({ success: true });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'ANNOUNCEMENT_ADMIN_DELETE') {
    (async () => {
      const id = Number(msg.id);
      if (!id) throw new Error('공지 ID가 없습니다.');
      await adminAnnouncementRequest(`/rest/v1/announcements?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE' });
      sendResponse({ success: true });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'AUTH_GET_SESSION') {
    getValidStoredAuth()
      .then(session => sendResponse({ success: true, session }))
      .catch(error => sendResponse({ success: false, session: null, error: error.message }));
    return true;
  }

  if (msg.type === 'AUTH_GET_PROFILE') {
    (async () => {
      const session = await getValidStoredAuth();
      if (!session?.access_token) {
        sendResponse({ success: false, error: '로그인이 필요합니다.' });
        return;
      }
      const profile = await fetchUserProfile(session);
      sendResponse({ success: true, session, profile });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'AUTH_CONSUME_USAGE') {
    (async () => {
      const session = await getValidStoredAuth();
      if (!session?.access_token) {
        sendResponse({ success: false, error: '로그인이 필요합니다.' });
        return;
      }
      const profile = await consumeFlowUsage(session, msg.units || 1);
      sendResponse({ success: true, session, profile });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'AUTH_SIGN_OUT') {
    clearStoredAuth()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'AUTH_SIGN_IN') {
    (async () => {
      if (!isAuthConfigured()) {
        throw new Error('Supabase URL과 anon key를 auth-config.js에 먼저 입력하세요.');
      }
      const cfg = getAuthConfig();
      const redirectUrl = chrome.identity.getRedirectURL('supabase');
      const authUrl = `${cfg.SUPABASE_URL.replace(/\/$/, '')}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectUrl)}&scopes=${encodeURIComponent('openid email profile')}`;
      const callbackUrl = await openAuthPopup(authUrl, redirectUrl);
      if (!callbackUrl) throw new Error('로그인 콜백을 받지 못했습니다.');
      const token = parseAuthRedirect(callbackUrl);
      if (!token.access_token) throw new Error('로그인 토큰을 받지 못했습니다. Supabase Redirect URL 설정을 확인하세요.');
      const user = await fetchSupabaseUser(token);
      const session = {
        access_token: token.access_token,
        refresh_token: token.refresh_token,
        expires_at: Date.now() + token.expires_in * 1000,
        user: {
          id: user.id,
          email: user.email,
          name: user.user_metadata?.full_name || user.user_metadata?.name || user.email || '사용자'
        }
      };
      await setStoredAuth(session);
      sendResponse({ success: true, session });
    })().catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (msg.type === 'GET_FLOW_TAB') {
    // 현재 활성화된 창의 탭들을 먼저 확인
    chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
      const activeTab = activeTabs[0];
      
      if (activeTab && isFlowUrl(activeTab.url)) {
        sendResponse({ tab: activeTab });
      } else {
        // 현재 탭이 아니면 전체 탭에서 Flow 탭 탐색
        chrome.tabs.query({}, (tabs) => {
          const flowTab = tabs.find(t => isFlowUrl(t.url));
          sendResponse({ tab: flowTab || null });
        });
      }
    });
    return true; // 비동기 응답을 위해 true 반환
  }

  if (msg.type === 'DEBUGGER_CLICK') {
    const target = { tabId: msg.tabId };
    const x = Math.round(msg.x);
    const y = Math.round(msg.y);

    const detach = () => chrome.debugger.detach(target, () => void chrome.runtime.lastError);

    chrome.debugger.attach(target, '1.3', () => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
        return;
      }

      chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x,
        y,
        button: 'left',
        buttons: 1,
        clickCount: 1
      }, () => {
        if (chrome.runtime.lastError) {
          const error = chrome.runtime.lastError.message;
          detach();
          sendResponse({ success: false, error });
          return;
        }

        chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          x,
          y,
          button: 'left',
          buttons: 0,
          clickCount: 1
        }, () => {
          const error = chrome.runtime.lastError?.message;
          detach();
          sendResponse(error ? { success: false, error } : { success: true });
        });
      });
    });
    return true;
  }
});

// 자동 다운로드 파일명 지정 로직
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  chrome.storage.local.get(['dlPrefix', 'autoDl'], (res) => {
    if (res.autoDl && res.dlPrefix && (item.url.includes('googleusercontent.com') || item.url.includes('labs.google'))) {
      // 파일명에서 금지된 문자 제거 및 길이 제한
      const safePrefix = res.dlPrefix.replace(/[\\/:*?"<>|]/g, '_').substring(0, 50);
      const timestamp = new Date().getTime().toString().slice(-4);
      const extension = item.filename.split('.').pop() || 'png';
      
      suggest({
        filename: `Flow_${safePrefix}_${timestamp}.${extension}`,
        conflictAction: 'uniquify'
      });
    } else {
      suggest();
    }
  });
  return true;
});

console.log("[FlowMaster] Background Engine Loaded.");
